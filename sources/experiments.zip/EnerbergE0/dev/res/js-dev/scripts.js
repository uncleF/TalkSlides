/* jshint browser:true */

'use strict';

/* Utilities */

// const loadFonts = require('patterns/tx-loadFonts');

// loadFonts('PFDinDisplayPro', ['PFDinDisplayProBlack', 'ACityNovaBold']);

/* UI */

const contacts = require('ui/contacts');
const feedback = require('ui/feedback');
const form = require('ui/form');
const gallery = require('ui/gallery');
const infoTabs = require('ui/infoTabs');
const navigation = require('ui/navigation');
const shopNav = require('ui/shopNavigation');
const sideNav = require('ui/sideNavigation');
const sideNavPhone = require('ui/sideNavigationPhone');
const social = require('ui/social');
const tiles = require('ui/tiles');

contacts();
feedback();
form();
gallery();
infoTabs();
navigation();
shopNav();
sideNav();
sideNavPhone();
tiles();
social();

/* Data */

const feedbackForm = require('data/feedbackForm');

feedbackForm();

/* Catalog */

const filters = require('filter/filters');
const filterTabs = require('filter/filterTabs');

filters();
filterTabs();

/* Cart */

const cart = require('cart/cart');

cart();
