/* jshint browser:true */

'use strict';

module.exports = _ => {

    const filter = require('filter/filter');

    const FILTER_CLASS_NAME = 'filter';
    const CATALOG_ITEM_CLASS_NAME = 'catalogTableItem';
    const CATALOG_ITEM_HIDDEN_CLASS_NAME = 'catalogTableItem-is-hidden';
    const CATALOG_ITEM_EVEN_CLASS_NAME = 'catalogTableItem-is-even';
    const CATALOG_ITEM_ODD_CLASS_NAME = 'catalogTableItem-is-odd';
    const FILTER_MODEL_ID = 'filter-model';
    const FILTER_TECH_ID = 'filter-tech';
    const CATALOG_LINK_CLASS = 'catalogTableLink';

    let catalogItemElements;
    let catalogItems;

    let filters;
    let currentConditions;

    function createItem(itemElement) {
        return {
            dom: itemElement,
            conditions: itemElement.dataset
        };
    }

    function filterItem(item) {
        item.dom.classList.remove(CATALOG_ITEM_ODD_CLASS_NAME, CATALOG_ITEM_EVEN_CLASS_NAME);
        const passes = currentConditions.every(filterItem => {
            if (typeof filterItem.value === 'object') {
                const value = item.conditions[filterItem.name] - 0;
                const min = filterItem.value[0] - 0;
                const max = filterItem.value[1] - 0;
                return value >= min && value <= max;
            } else {
                const values = item.conditions[filterItem.name].split(',');
                return values.indexOf(filterItem.value) > -1;
            }
        });
        if (!passes) {
            item.dom.classList.add(CATALOG_ITEM_HIDDEN_CLASS_NAME);
        } else {
            item.dom.classList.remove(CATALOG_ITEM_HIDDEN_CLASS_NAME);
        }
    }

    function selectFiltered(item) {
        return !item.dom.classList.contains(CATALOG_ITEM_HIDDEN_CLASS_NAME);
    }

    function paintFiltered(item, index) {
        if (index % 2 !== 0) {
            item.dom.classList.add(CATALOG_ITEM_EVEN_CLASS_NAME);
        } else {
            item.dom.classList.add(CATALOG_ITEM_ODD_CLASS_NAME);
        }
    }

    function updateLinks(item) {
        const link = item.dom.getElementsByClassName(CATALOG_LINK_CLASS)[0];
        link.href = link.href.replace(/\?.*/, '')
        link.href += `?modelId=${filterModel.value}`;
    }

    function filterCatalog() {
        catalogItems.forEach(filterItem);
        catalogItems.filter(selectFiltered).forEach(paintFiltered)
        if (filterModel) {
            catalogItems.filter(selectFiltered).forEach(updateLinks);
        }
    }

    function updateOptions(value) {
        const options = [].slice.call(filterModel.getElementsByTagName('option'));
        options.forEach(option => {
            const values = option.getAttribute('data-tech').split(',');
            if (values.indexOf(value) > -1) {
                option.removeAttribute('disabled');
                option.classList.remove('filterOption-is-disabled');
            } else {
                option.setAttribute('disabled', 'disabled');
                option.classList.add('filterOption-is-disabled');
            };
        });
        options[0].setAttribute('selected', 'selected');
    }

    function onFilterReset() {
        catalogItemElements.forEach(element => element.classList.remove(CATALOG_ITEM_HIDDEN_CLASS_NAME));
        currentConditions = [];
    }

    function onFilterUpdate(event) {
        if (filterTech) {
            updateOptions(filterTech.value);
        }
        currentConditions = event.data.conditions;
        filterCatalog();
    }

    function init() {
        filters = filterElements.map(filter);
        document.addEventListener('fltr:update', onFilterUpdate);
        document.addEventListener('fltr:reset', onFilterReset);
        filters[0].trigger();
    }

    const filterElements = [].slice.call(document.getElementsByClassName(FILTER_CLASS_NAME));
    const filterModel = document.getElementById(FILTER_MODEL_ID);
    const filterTech = document.getElementById(FILTER_TECH_ID);

    if (filterElements.length > 0) {
        catalogItemElements = [].slice.call(document.getElementsByClassName(CATALOG_ITEM_CLASS_NAME));
        catalogItems = catalogItemElements.map(createItem);
        init();
    }

};
