/* jshint browser:true */

'use strict';

module.exports = dom => {

    const eventManager = require('patterns/tx-event');

    const FILTER_SELECT_CLASS_NAME = 'filterSelect';

    let conditions;

    function transmitEvent() {
        eventManager.trigger(document, 'fltr:update', false, 'UIEvent', {conditions: conditions});
    }

    function updateCondition(select) {
        const spread = select.dataset.spread;
        let value;
        if (spread) {
            const connectedValue = document.getElementById(spread).value;
            value = select.dataset.hasOwnProperty('min') ? [select.value, connectedValue] : [connectedValue, select.value];
        } else {
            value = select.value;
        }
        return {
            name: select.dataset.key,
            value: value
        };
    }

    function updateConditions() {
        conditions = filterSelects.map(updateCondition);
    }

    function onChange() {
        updateConditions();
        transmitEvent();
    }

    function init() {
        filterElement.addEventListener('change', onChange, true);
        updateConditions();
    }

    const filterElement = dom;
    const filterSelects = [].slice.call(dom.getElementsByClassName(FILTER_SELECT_CLASS_NAME));

    init();

    return {
        trigger: onChange
    };

};
