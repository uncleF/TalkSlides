/* jshint browser:true */

'use strict';

module.exports = _ => {

    const eventManager = require('patterns/tx-event');

    const TAB_CLASS_NAME = 'filterTabLink';
    const TAB_ACTIVE_CLASS_NAME = 'filterTabLink-is-active';
    const TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME = 'filter-is-active';

    let activeTab;
    let activeContent;

    function transmitEvent() {
        eventManager.trigger(document, 'fltr:reset', false, 'UIEvent');
    }

    function deactivateActive() {
        activeTab.classList.remove(TAB_ACTIVE_CLASS_NAME);
        activeContent.classList.remove(TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME);
    }

    function activateNew(tab, content) {
        tab.classList.add(TAB_ACTIVE_CLASS_NAME);
        content.classList.add(TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME);
    }

    function onClick(event, link, content) {
        event.preventDefault();
        if (link !== activeTab) {
            if (activeTab) {
                deactivateActive();
            }
            activateNew(link, content);
            activeTab = link;
            activeContent = content;
            transmitEvent();
        }
    }

    function addPair(link, index) {
        let contentId = link.getAttribute('href').replace('#', '');
        let content = document.getElementById(contentId);
        link.addEventListener('click', event => onClick(event, link, content));
        if (index === 0) {
            activeTab = link;
            activeContent = content;
        }
    }

    let tabObjects = document.getElementsByClassName(TAB_CLASS_NAME);

    if (tabObjects) {
        tabObjects = [].slice.call(tabObjects);
        tabObjects.forEach(addPair);
    }

};
