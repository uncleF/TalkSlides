/* jshint browser:true */

'use strict';

module.exports = _ => {

    const nanoajax = require('nanoajax');

    const URL = '/api/question';

    const FEEDBACK_FORM_ID = 'feedback';
    const FEEDBACK_SUCESS_ID = 'feedbackSuccessMessage';
    const FEEDBACK_SUCESS_ACTIVE_CLASS_NAME = 'feedbackSuccessMessage-is-active';
    const FEEDBACK_FAIL_ID = 'feedbackFailMessage';
    const FEEDBACK_FAIL_ACTIVE_CLASS_NAME = 'feedbackFailMessage-is-active';
    const FEEDBACK_RETRY_ID = 'feedbackRetry';
    const FEEDBACK_ELEMENTS = '.feedbackText, .feedbackField';
    const FEEDBACK_SUBMIT_ID = 'feedbackSubmit';
    const FEEDBACK_SUBMIT_DISABLED_CLASS_NAME = 'feedbackSubmit-is-disabled';
    const ELEMENT_ERROR_CLASS_NAME = 'feedbackItem-has-error';

    const TOKEN_ID = 'csrf';

    let elements;
    let success;
    let fail;
    let retry;
    let submit;

    function hideSuccess() {
        feedback.reset();
        success.classList.remove(FEEDBACK_SUCESS_ACTIVE_CLASS_NAME);
    }

    function showSuccess() {
        success.classList.add(FEEDBACK_SUCESS_ACTIVE_CLASS_NAME);
        setTimeout(hideSuccess, 2000);
    }

    function hideFail() {
        fail.classList.remove(FEEDBACK_FAIL_ACTIVE_CLASS_NAME);
    }

    function showFail() {
        fail.classList.add(FEEDBACK_FAIL_ACTIVE_CLASS_NAME);
    }

    function validateElement(element) {
        let value = element.value.trim();
        if (!value || value === '') {
            return false;
        } else {
            return true;
        }
    }

    function validateForm() {
        return elements.every(validateElement);
    }

    function onResponse(code) {
        if (code === 200) {
            showSuccess();
        } else {
            showFail();
        }
    }

    function formData() {
        let data = [];
        let id = feedback.getAttribute('data-item-id');
        elements.forEach(element => data.push(`${element.name}=${element.value.trim()}`));
        data.push(`url=${window.location.href}`);
        if (id && id !== '') {
            data.push(`product_id=${id}`);
        }
        return data.join('&');
    }

    function sendForm() {
        nanoajax.ajax({
            url: URL,
            method: 'POST',
            headers: {'X-CSRF-TOKEN': document.getElementById(TOKEN_ID).getAttribute('content')},
            body: formData()
        }, onResponse);
    }

    function markElement(element) {
        if (!element.value.trim() || element.value.trim() === '') {
            element.parentElement.classList.add(ELEMENT_ERROR_CLASS_NAME);
        }
    }

    function markInvalid() {
        elements.forEach(markElement);
    }

    function lockForm() {
        submit.setAttribute('disabled', 'disabled');
        submit.classList.add(FEEDBACK_SUBMIT_DISABLED_CLASS_NAME);
    }

    function unlockForm() {
        submit.removeAttribute('disabled');
        submit.classList.remove(FEEDBACK_SUBMIT_DISABLED_CLASS_NAME);
    }

    function onFormSubmit(event) {
        event.preventDefault();
        if (validateForm()) {
            sendForm();
        } else {
            markInvalid();
        }
    }

    function onElementFocus(event) {
        event.target.parentElement.classList.remove(ELEMENT_ERROR_CLASS_NAME);
    }

    function onElementInput(event) {
        if (validateForm()) {
            unlockForm();
        } else {
            lockForm();
        }
    }

    function onRetryClick(event) {
        event.preventDefault();
        hideFail();
    }

    function subscribe() {
        feedback.addEventListener('submit', onFormSubmit);
        feedback.addEventListener('input', onElementInput, true);
        feedback.addEventListener('keyup', onElementInput, true);
        feedback.addEventListener('change', onElementInput, true);
        feedback.addEventListener('focus', onElementFocus, true);
        retry.addEventListener('click', onRetryClick);
    }

    const feedback = document.getElementById(FEEDBACK_FORM_ID);
    if (feedback) {
        elements = [...feedback.querySelectorAll(FEEDBACK_ELEMENTS)];
        success = document.getElementById(FEEDBACK_SUCESS_ID);
        fail = document.getElementById(FEEDBACK_FAIL_ID);
        retry = document.getElementById(FEEDBACK_RETRY_ID);
        submit = document.getElementById(FEEDBACK_SUBMIT_ID);
        subscribe();
    }

};
