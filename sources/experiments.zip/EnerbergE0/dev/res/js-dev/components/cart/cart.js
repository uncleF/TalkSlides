/* jshint browser:true */

'use strict';

module.exports = _ => {

    const nanoajax = require('nanoajax');
    const eventManager = require('patterns/tx-event');

    const ADD_ID = 'addCart';
    const ADD_URL = '/api/cart/add';
    const ITEM_ID_ID = 'itemID';
    const ITEM_TYPE_ID = 'itemType';
    const ITEM_QUANTITY_ID = 'itemQuantity';

    const REMOVE_URL = '/api/cart/delete';
    const REMOVE_CART_LINK_CLASS_NAME = 'cartListItemRemove';
    const REMOVE_TABLE_LINK_CLASS_NAME = 'cartRemoveItem';

    const UPDATE_URL = '/api/cart';

    const CART_ID = 'cart';
    const CART_LIST_ID = 'cartList';
    const CART_COUNTER_ID = 'cartCount';
    const CART_QUANTITY_ID = 'cartTotalQuantity';
    const CART_SUM_ID = 'cartTotalSum';

    const TABLE_ID = 'cartTable';
    const TABLE_QUANTITY_ID = 'cartTableTotalQuantity';
    const TABLE_SUM_ID = 'cartTableTotalSum';
    const ADD_ACCESSORY_CLASS_NAME = 'cartAdd';
    const ACCESSORY_SUB_CLASS_NAME = 'sideShopNavLink-accessory';

    const CLEAR_URL = '/api/cart/clear';
    const CLEAR_ID = 'cartClear';

    const AMMOUNT_CLASS_NAME = 'aSField';
    const AMMOUNT_DELAY = 200;

    let add;
    let itemID;
    let itemType;
    let itemQuantity;

    let cart;
    let cartList;
    let cartCounter;
    let cartQuantity;
    let cartSum;
    let cartData;

    let table;
    let tableQuantity;
    let tableSum;
    let accessorySub;

    let clear;

    let ammountDelay;

    function collectAddItemData() {
        return `product_id=${itemID.value}&product_type=${itemType.value}&quantity=${itemQuantity.value}`;
    }

    function collectRemoveItemData(element) {
        return `product_id=${element.getAttribute('data-id')}&product_type=${element.getAttribute('data-type')}`;
    }

    function collectUpdateItemData(element) {
        return `product_id=${element.getAttribute('data-id')}&product_type=${element.getAttribute('data-type')}&quantity=${element.value}`;
    }

    function getTopCartItem(items, item) {
        const listItem = `<li class="cartListItem">
                              <img src="${item.product.image}" class="cartListImage" alt="">
                              <span class="cartListItemName">${item.product.manufacturer.name} ${item.product.name}</span>
                              <a href="#" class="cartListItemRemove">Удалить</a>
                          </li>`;
        return {
            list: items.list + listItem,
            count: items.count + (item.quantity - 0),
            sum: items.sum + (item.quantity - 0) * (item.product.cost - 0)
        };
    }

    function numberWithSpaces(number) {
        return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    }

    function updateTopCart(data) {
        if (cart) {
            if (data.count > 0) {
                cartCounter.textContent = data.count;
                cartQuantity.textContent = `${data.items.count} шт`;
                cartSum.innerHTML = `${numberWithSpaces(data.items.sum)} р`;
                cartList.innerHTML = data.items.list;
            } else {
                cartCounter.textContent = '';
                cartQuantity.textContent = 0;
                cartSum.textContent = 0;
                cartList.innerHTML = '';
            }
        }
    }

    function updateContentCart(data) {
        if (table) {
            if (data.count > 0) {
                tableQuantity.textContent = `${data.items.count} шт`;
                tableSum.innerHTML = `${numberWithSpaces(data.items.sum)} р`;
            } else {
                tableQuantity.textContent = 0;
                tableSum.innerHTML = 0;
            }
        }
    }

    function onResponse(code) {
        if (code === 200) {
            updateCart();
        }
    }

    function onUpdateResponse(code, response) {
        if (code === 200) {
            const json = JSON.parse(response);
            cartData = {
                count: json.length,
                items: json.reduce(getTopCartItem, {list: '', count: 0, sum: 0})
            };
            updateTopCart(cartData);
            updateContentCart(cartData);
        }
    }

    function onClearResponse(code) {

    }

    function sendAddItem(data) {
        nanoajax.ajax({
            url: ADD_URL,
            method: 'POST',
            body: data
        }, onResponse);
    }

    function sendRemoveItem(data) {
        nanoajax.ajax({
            url: REMOVE_URL,
            method: 'POST',
            body: data
        }, onResponse);
    }

    function sendUpdateCart() {
        nanoajax.ajax({
            url: UPDATE_URL,
            method: 'GET',
        }, onUpdateResponse);
    }

    function sendClearCart() {
        nanoajax.ajax({
            url: CLEAR_URL,
            method: 'POST'
        }, onClearResponse);
    }

    function sendUpdateItem(data) {
        nanoajax.ajax({
            url: ADD_URL,
            method: 'POST',
            body: data
        }, onResponse);
    }

    function updateCart() {
        sendUpdateCart();
    }

    function addItem() {
        const data = collectAddItemData();
        sendAddItem(data);
    }

    function removeCartItem(link) {
        const data = collectRemoveItemData(link);
        link.parentElement.remove();
        if (table) {
            const tableLink = [].slice.call(table.getElementsByClassName(REMOVE_TABLE_LINK_CLASS_NAME)).filter(removeLink => {
                const attrID = link.getAttribute('data-id') === removeLink.getAttribute('data-id');
                const attrType = link.getAttribute('data-type') === removeLink.getAttribute('data-type');
                return attrID && attrType;
            });
            tableLink[0].parentElement.parentElement.remove();
        }
        sendRemoveItem(data);
    }

    function removeTableItem(link) {
        const data = collectRemoveItemData(link);
        link.parentElement.parentElement.remove();
        if (cart) {
            const cartLink = [].slice.call(cart.getElementsByClassName(REMOVE_CART_LINK_CLASS_NAME)).filter(removeLink => {
                const attrID = link.getAttribute('data-id') === removeLink.getAttribute('data-id');
                const attrType = link.getAttribute('data-type') === removeLink.getAttribute('data-type');
                return attrID && attrType;
            });
            cartLink[0].parentElement.remove();
        }
        sendRemoveItem(data);
    }

    function clearCart() {
        if (cartList) {
            cartCounter.textContent = '';
            cartQuantity.textContent = 0;
            cartSum.textContent = 0;
            cartList.innerHTML = '';
        }
        if (table) {
            tableQuantity.textContent = 0;
            tableSum.innerHTML = 0;
            table.getElementsByTagName('tbody')[0].innerHTML = '';
        }
        sendClearCart();
    }

    function updateItemAmmount(target) {
        const data = collectUpdateItemData(target);
        sendUpdateItem(data);
    }

    function onAddClick(event) {
        event.preventDefault();
        addItem();
    }

    function onCartClick(event) {
        const target = event.target;
        if (target.className === REMOVE_CART_LINK_CLASS_NAME) {
            event.preventDefault();
            removeCartItem(target);
        }
    }

    function onTableClick(event) {
        const target = event.target;
        if (target.className === REMOVE_TABLE_LINK_CLASS_NAME) {
            event.preventDefault();
            removeTableItem(target);
        } else if (target.className === ADD_ACCESSORY_CLASS_NAME) {
            event.preventDefault();
            eventManager.trigger(accessorySub, 'click');
        }
    }

    function onTableChange(event) {
        const target = event.target;
        if (target.className === AMMOUNT_CLASS_NAME) {
            event.preventDefault();
            clearTimeout(ammountDelay);
            ammountDelay = setTimeout(_ => updateItemAmmount(target), AMMOUNT_DELAY);
        }
    }

    function onClearClick(event) {
        event.preventDefault();
        clearCart();
    }

    add = document.getElementById(ADD_ID);
    cart = document.getElementById(CART_ID);
    table = document.getElementById(TABLE_ID);
    clear = document.getElementById(CLEAR_ID);

    if (add) {
        itemID = document.getElementById(ITEM_ID_ID);
        itemType = document.getElementById(ITEM_TYPE_ID);
        itemQuantity = document.getElementById(ITEM_QUANTITY_ID);
        add.addEventListener('click', onAddClick);
    }

    if (cart) {
        cartCounter = document.getElementById(CART_COUNTER_ID);
        cartList = document.getElementById(CART_LIST_ID);
        cartQuantity = document.getElementById(CART_QUANTITY_ID);
        cartSum = document.getElementById(CART_SUM_ID);
        cart.addEventListener('click', onCartClick);
    }

    if (table) {
        tableQuantity = document.getElementById(TABLE_QUANTITY_ID);
        tableSum = document.getElementById(TABLE_SUM_ID);
        accessorySub = document.getElementsByClassName(ACCESSORY_SUB_CLASS_NAME)[0];
        table.addEventListener('click', onTableClick);
        table.addEventListener('ast:change', onTableChange, false);
    }

    if (clear) {
        clear.addEventListener('click', onClearClick);
    }

};
