/* jshint browser:true */

'use strict';

var eventTool = require('./tx-event');

const WRAP_CLASS_NAME_SUFFIX = '-wrap';
const VALUE_CLASS_NAME_SUFFIX = '-value';
const BUTTON_CLASS_NAME_SUFFIX = '-button';
const REMOVE_CLASS_NAME_SUFFIX = '-remove';
const WRAPED_CLASS_NAME_SUFFIX = '-is-wrapped';
const FILLED_CLASS_NAME_SUFFIX = '-has-file';

/* HTML */

function createWrap(className) {
    var element = document.createElement('div');
    element.className = `${className}${WRAP_CLASS_NAME_SUFFIX}`;
    return element;
}

function createValue(className) {
    var element = document.createElement('div');
    element.className = `${className}${VALUE_CLASS_NAME_SUFFIX}`;
    return element;
}

function createButton(className, classNameSuffix, text) {
    var element = document.createElement('a');
    element.href = '#';
    element.textContent = text;
    element.className = `${className}${classNameSuffix}`;
    return element;
}

function wrapInput(className, input, wrap, value, attach, remove) {
    var parent = input.parentNode;
    wrap.appendChild(value);
    wrap.appendChild(remove);
    wrap.appendChild(attach);
    parent.insertBefore(wrap, input);
    input.classList.add(`${className}${WRAPED_CLASS_NAME_SUFFIX}`);
    wrap.appendChild(input);
}

/* Field Constructor */

function fileInput(field, textAttach, textRemove) {

    var input;
    var className;
    var wrap;
    var value;
    var buttonAttach;
    var buttonRemove;

    /* Field Interactions */

    function onChange(event) {
        const newValue = input.value.split('\\')[2];
        if (newValue) {
            value.textContent = newValue;
            wrap.classList.add(`${className}${FILLED_CLASS_NAME_SUFFIX}`);
        } else {
            value.textContent = '';
            wrap.classList.remove(`${className}${FILLED_CLASS_NAME_SUFFIX}`);
        }
        console.log(input.value);
    }

    function onButtonClick(event) {
        event.preventDefault();
        eventTool.trigger(input, 'click');
    }

    function onRemoveClick(event) {
        event.preventDefault();
        input.value = '';
        value.textContent = '';
        wrap.classList.remove(`${className}${FILLED_CLASS_NAME_SUFFIX}`);
    }

    function initInteractions() {
        eventTool.bind(input, 'change', onChange);
        eventTool.bind(buttonAttach, 'click', onButtonClick);
        eventTool.bind(buttonRemove, 'click', onRemoveClick);
    }

    function removeInteractions() {
        eventTool.unbind(input, 'change', onChange);
        eventTool.unbind(buttonAttach, 'click', onButtonClick);
        eventTool.unbind(buttonRemove, 'click', onRemoveClick);
    }

    /* Field Initialization */

    function initValues() {
        input = field;
        className = input.classList.item(0);
        wrap = createWrap(className);
        value = createValue(className);
        buttonAttach = createButton(className, BUTTON_CLASS_NAME_SUFFIX, textAttach);
        buttonRemove = createButton(className, REMOVE_CLASS_NAME_SUFFIX, textRemove);
    }

    function initField() {
        initValues();
        wrapInput(className, input, wrap, value, buttonAttach, buttonRemove);
        initInteractions();
    }

    function removeValues() {
        input = null;
        className = null;
        wrap = null;
        value = null;
        buttonAttach = null;
        buttonRemove = null;
    }

    function destroyField() {
        removeInteractions();
        removeValues();
    }

    initField();

    /* Field Interface */

    return {
        destroy: destroyField
    };

}

/* Initialization */

function init(selector, textAttach, textRemove) {
    var fields = [].slice.call(document.querySelectorAll(selector));
    fields.forEach(field => fileInput(field, textAttach, textRemove));
}

function destroy(fields) {
    fields.forEach(field => field.destroy());
}

/* Interface */

exports.init = init;
exports.destroy = destroy;
