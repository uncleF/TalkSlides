/* jshint browser:true */

'use strict';

module.exports = _ => {

    const PHONE_THRESHOLD = 980;

    function phone() {
        return window.innerWidth <= PHONE_THRESHOLD;
    }

    function desktop() {
        return window.innerWidth > PHONE_THRESHOLD;
    }

    return {
        phone: phone,
        desktop: desktop
    };

};
