/* jshint browser:true */

'use strict';

module.exports = [{
    'elementType': 'geometry',
    'featureType': 'water',
    'stylers': [
        {
            'color': '#e9e9e9'
        },
        {
            'lightness': 17
        }
    ]
}, {
    'elementType': 'geometry',
    'featureType': 'landscape',
    'stylers': [
        {
            'color': '#f5f5f5'
        },
        {
            'lightness': 20
        }
    ]
}, {
    'elementType': 'geometry.fill',
    'featureType': 'road.highway',
    'stylers': [
        {
            'color': '#ffffff'
        },
        {
            'lightness': 17
        }
    ]
}, {
    'elementType': 'geometry.stroke',
    'featureType': 'road.highway',
    'stylers': [
        {
            'color': '#ffffff'
        },
        {
            'lightness': 29
        },
        {
            'weight': 0.2
        }
    ]
}, {
    'elementType': 'geometry',
    'featureType': 'road.arterial',
    'stylers': [
        {
            'color': '#ffffff'
        },
        {
            'lightness': 18
        }
    ]
}, {
    'elementType': 'geometry',
    'featureType': 'road.local',
    'stylers': [
        {
            'color': '#ffffff'
        },
        {
            'lightness': 16
        }
    ]
}, {
    'elementType': 'geometry',
    'featureType': 'poi',
    'stylers': [
        {
            'color': '#f5f5f5'
        },
        {
            'lightness': 21
        }
    ]
}, {
    'elementType': 'geometry',
    'featureType': 'poi.park',
    'stylers': [
        {
            'color': '#dedede'
        },
        {
            'lightness': 21
        }
    ]
}, {
    'elementType': 'labels.text.stroke',
    'stylers': [
        {
            'visibility': 'on'
        },
        {
            'color': '#ffffff'
        },
        {
            'lightness': 16
        }
    ]
}, {
    'elementType': 'labels.text.fill',
    'stylers': [
        {
            'saturation': 36
        },
        {
            'color': '#333333'
        },
        {
            'lightness': 40
        }
    ]
}, {
    'elementType': 'labels.icon',
    'stylers': [
        {
            'visibility': 'off'
        }
    ]
}, {
    'elementType': 'geometry',
    'featureType': 'transit',
    'stylers': [
        {
            'color': '#f2f2f2'
        },
        {
            'lightness': 19
        }
    ]
}, {
    'elementType': 'geometry.fill',
    'featureType': 'administrative',
    'stylers': [
        {
            'color': '#fefefe'
        },
        {
            'lightness': 20
        }
    ]
}, {
    'elementType': 'geometry.stroke',
    'featureType': 'administrative',
    'stylers': [
        {
            'color': '#fefefe'
        },
        {
            'lightness': 17
        },
        {
            'weight': 1.2
        }
    ]
  }
];
