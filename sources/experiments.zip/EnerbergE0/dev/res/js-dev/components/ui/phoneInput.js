/* jshint browser:true */

'use strict';

module.exports = _ => {

    const Numbered = require('input.numbered');

    const PHONE_INPUT_CLASS_NAME = 'formField-phone';
    const ERROR_CLASS_NAME = 'formItem-has-error';

    const OPTIONS = {
        mask: '+7 (###) ### - ## - ##',
        numbered: '#',
        empty: '_',
        placeholder: true
    };

    let phoneFields;

    function onBlur(event) {
        const target = event.target;
        const filtered = phoneFields.filter(phoneField => phoneField.dom === target);
        const valid = filtered[0].numbered.validate();
        if (valid <= 0) {
            target.parentElement.classList.add(ERROR_CLASS_NAME);
        }
    }

    function onFocus(event) {
        event.target.parentElement.classList.remove(ERROR_CLASS_NAME);
    }

    function initField(field) {
        const numbered = new Numbered(field, OPTIONS);
        field.addEventListener('blur', onBlur);
        field.addEventListener('focus', onFocus);
        return {
            dom: field,
            numbered: numbered
        };
    }

    function init() {
        phoneFields = fields.map(initField);
    }

    const fields = [].slice.call(document.getElementsByClassName(PHONE_INPUT_CLASS_NAME));

    init();

};
