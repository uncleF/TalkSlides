/* jshint browser:true */

'use strict';

module.exports = _ => {

    const slider = require('patterns/tx-slider');

    const GALLERY_ID = 'galleryItems';
    const GALLERY_ITEM_CLASS_NAME = 'galleryItem';
    const GALLERY_DOTS_CLASS_NAME = 'galleryDots';
    const GALLERY_DOT_CLASS_NAME = 'galleryDot';

    let dots;

    function init() {
        dots = slider.dots(gallerySize, GALLERY_DOTS_CLASS_NAME, GALLERY_DOT_CLASS_NAME);
        gallery.parentElement.appendChild(dots);
        slider.init(gallery, dots, GALLERY_DOT_CLASS_NAME);
    }

    const gallery = document.getElementById(GALLERY_ID);
    const galleryItems = [].slice.call(gallery.getElementsByClassName(GALLERY_ITEM_CLASS_NAME));
    const gallerySize = galleryItems.length;

    init();

};
