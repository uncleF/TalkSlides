/* jshint browser:true */

'use strict';

module.exports = _ => {

    const NAV_ID = 'navigation';
    const NAV_TOGGLE_ID = 'navToggle';
    const NAV_ITEM_CLASS_NAME = 'navItem';
    const NAV_ITEM_ACTIVE_CLASS_NAME = 'navItem-is-active';
    const FEEDBACK_ID = 'feedback';
    const FEEDBACK_SHOW_NAV_ID = 'showFeedback';
    const FEEDBACK_SHOW_SIDE_ID = 'writeUs';
    const FEEDBACK_SHOW_ASK_ID = 'askQuestion';
    const FEEDBACK_CLOSE_ID = 'closeFeedback';
    const CART_ID = 'cart';
    const CART_ACTIVE_CLASS_NAME = 'cart-is-active';
    const ACTIVE_SUFFIX = '-is-active';
    const BACK_LINK_ID = 'backLink';

    let navigation;
    let navigationActive;
    let navigationItems;
    let navToggle;
    let navToggleActive;
    let feedback;
    let feedbackShowNav;
    let feedbackShowSide;
    let feedbackShowAsk;
    let feedbackClose;
    let feedbackActive;
    let cartHolder;
    let backLink;

    function toggleNav() {
        navToggle.classList.toggle(navToggleActive);
        navigation.classList.toggle(navigationActive);
    }

    function clearItemData() {
        feedback.removeAttribute('data-item-id');
    }

    function insertItemData(id) {
        feedback.setAttribute('data-item-id', id);
    }

    function toggleFeedback() {
        feedback.reset();
        feedback.classList.toggle(feedbackActive);
    }

    function onNavClick(event) {
        event.preventDefault();
        event.stopPropagation();
        toggleNav();
    }

    function onFeedbackClick(event) {
        event.preventDefault();
        event.stopPropagation();
        toggleFeedback();
        clearItemData();
    }

    function onFeedbackItemClick(event) {
        onFeedbackClick(event);
        insertItemData(feedbackShowAsk.getAttribute('data-item-id'));
    }

    function onCartOver(event) {
        event.target.classList.add(CART_ACTIVE_CLASS_NAME);
    }

    function onCartOut(event) {
        event.target.classList.remove(CART_ACTIVE_CLASS_NAME);
    }

    function initInteractions() {
        navToggle.addEventListener('click', onNavClick);
        feedbackShowNav.addEventListener('click', onFeedbackClick);
        feedbackClose.addEventListener('click', onFeedbackClick);
        if (feedbackShowSide) {
            feedbackShowSide.addEventListener('click', onFeedbackClick);
        }
        if (feedbackShowAsk) {
            feedbackShowAsk.addEventListener('click', onFeedbackItemClick);
        }
        cartHolder.addEventListener('mouseenter', onCartOver);
        cartHolder.addEventListener('mouseleave', onCartOut);
    }

    function onBackClick(event) {
        event.preventDefault();
        if (window.history.length > 0) {
            window.history.back();
        }
    }

    function initNavItemIntreactions() {
        [].slice.call(navigationItems).forEach(item => {
            item.addEventListener('mouseenter', () => item.classList.add(NAV_ITEM_ACTIVE_CLASS_NAME));
            item.addEventListener('mouseleave', () => item.classList.remove(NAV_ITEM_ACTIVE_CLASS_NAME));
        });
    }

    navigation = document.getElementById(NAV_ID);
    if (navigation) {
        navigationActive = `${NAV_ID}${ACTIVE_SUFFIX}`;
        navigationItems = document.getElementsByClassName(NAV_ITEM_CLASS_NAME);
        navToggle = document.getElementById(NAV_TOGGLE_ID);
        navToggleActive = `${NAV_TOGGLE_ID}${ACTIVE_SUFFIX}`;
        feedback = document.getElementById(FEEDBACK_ID);
        feedbackShowNav = document.getElementById(FEEDBACK_SHOW_NAV_ID);
        feedbackShowSide = document.getElementById(FEEDBACK_SHOW_SIDE_ID);
        feedbackShowAsk = document.getElementById(FEEDBACK_SHOW_ASK_ID);
        feedbackClose = document.getElementById(FEEDBACK_CLOSE_ID);
        feedbackActive = `${FEEDBACK_ID}${ACTIVE_SUFFIX}`;
        cartHolder = document.getElementById(CART_ID);
        initInteractions();
        initNavItemIntreactions();
    }

    backLink = document.getElementById(BACK_LINK_ID);
    if (backLink) {
        backLink.addEventListener('click', onBackClick);
    }

};
