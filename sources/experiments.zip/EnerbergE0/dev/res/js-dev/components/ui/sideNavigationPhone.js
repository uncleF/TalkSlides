/* jshint browser:true */

'use strict';

module.exports = _ => {

    const BATTTERIES_TAB_ID = 'sideSubNavPhoneToggle-batteries';
    const BATTTERIES_TAB_CONTENT_HOLDER_ID = 'sideSubNavPhoneHolder-batteries';
    const BATTTERIES_TAB_CONTENT_ID = 'sideSubNavPhone-batteries';
    const BATTTERIES_TAB_ACTIVE_CLASS_NAME = 'sideNavPhoneLink-battery-is-active';

    const ACCESSORIES_TAB_ID = 'sideSubNavPhoneToggle-accessories';
    const ACCESSORIES_TAB_CONTENT_HOLDER_ID = 'sideSubNavPhoneHolder-accessories';
    const ACCESSORIES_CONTENT_ID = 'sideSubNavPhone-accessories';
    const ACCESSORIES_TAB_ACTIVE_CLASS_NAME = 'sideNavPhoneLink-accessory-is-active';

    let batHolder;
    let batContent;

    let accHolder;
    let accContent;

    function batDeactivate() {
        batToggle.classList.remove(BATTTERIES_TAB_ACTIVE_CLASS_NAME);
        batHolder.removeAttribute('style');
        batActive = false;
    }

    function accDeactivate() {
        accToggle.classList.remove(ACCESSORIES_TAB_ACTIVE_CLASS_NAME);
        accHolder.removeAttribute('style');
        accActive = false;
    }

    function batActivate() {
        const height = batContent.clientHeight;
        batToggle.classList.add(BATTTERIES_TAB_ACTIVE_CLASS_NAME);
        batHolder.style.height = `${height}px`;
        console.log(height);
        batActive = true;
    }

    function accActivate() {
        const height = accContent.clientHeight;
        accToggle.classList.add(ACCESSORIES_TAB_ACTIVE_CLASS_NAME);
        accHolder.style.height = `${height}px`;
        accActive = true;
    }

    function onBatClick(event, link, content) {
        event.preventDefault();
        if (batActive) {
            batDeactivate();
        } else {
            batActivate();
            accDeactivate();
        }
    }

    function onAccClick(event, link, content) {
        event.preventDefault();
        if (accActive) {
            accDeactivate();
        } else {
            accActivate();
            batDeactivate();
        }
    }

    let batToggle = document.getElementById(BATTTERIES_TAB_ID);
    let batActive = false;

    if (batToggle) {
        batHolder = document.getElementById(BATTTERIES_TAB_CONTENT_HOLDER_ID);
        batContent = document.getElementById(BATTTERIES_TAB_CONTENT_ID);
        batToggle.addEventListener('click', onBatClick);
    }

    let accToggle = document.getElementById(ACCESSORIES_TAB_ID);
    let accActive = false;

    if (accToggle) {
        accHolder = document.getElementById(ACCESSORIES_TAB_CONTENT_HOLDER_ID);
        accContent = document.getElementById(ACCESSORIES_CONTENT_ID);
        accToggle.addEventListener('click', onAccClick);
    }

};
