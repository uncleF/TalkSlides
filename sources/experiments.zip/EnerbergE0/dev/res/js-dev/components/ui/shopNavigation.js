/* jshint browser:true */

'use strict';

module.exports = _ => {

    const TAB_CLASS_NAME = 'shopNavLink-toggle';
    const TAB_ACTIVE_CLASS_NAME = 'shopNavLink-is-active';
    const TAB_CONTENT_HOLDER_CLASS_NAME = 'subNav';

    let activeTab;
    let activeContent;

    function deactivateActive() {
        activeTab.classList.remove(TAB_ACTIVE_CLASS_NAME);
        activeContent.removeAttribute('style');
    }

    function activateNew(tab, content) {
        const height = content.getElementsByClassName(TAB_CONTENT_HOLDER_CLASS_NAME)[0].clientHeight;
        tab.classList.add(TAB_ACTIVE_CLASS_NAME);
        content.style.height = `${height}px`;
    }

    function onClick(event, link, content) {
        event.preventDefault();
        if (link !== activeTab) {
            if (activeTab) {
                deactivateActive();
            }
            activateNew(link, content);
            activeTab = link;
            activeContent = content;
        } else {
            deactivateActive();
            activeTab = null;
            activeContent = null;
        }
    }

    function addPair(link) {
        let contentId = link.getAttribute('href').replace('#', '');
        let content = document.getElementById(contentId);
        link.addEventListener('click', event => onClick(event, link, content));
    }

    let tabObjects = document.getElementsByClassName(TAB_CLASS_NAME);
    if (tabObjects) {
        tabObjects = [].slice.call(tabObjects);
        tabObjects.forEach(addPair);
    }

};
