/* jshint browser:true */
/* global google */

'use strict';

module.exports = _ => {
    const GM_SCRIPT_URL = 'http://maps.google.com/maps/api/js?sensor=false';
    const MARKER_ICON = '/assets/frontend/images/marker.png';

    const MAP_STYLES = require('ui/mapStyles');

    const MAP_CLASS_NAME = 'contactMap';

    let maps;
    let centers;

    function initMarker(center, map, icon) {
        return new google.maps.Marker({
            position: center,
            map: map,
            icon: MARKER_ICON
        });
    }

    function initMap(dom) {
        const latlon = dom.getAttribute('data-location').split(',');
        if (dom) {
            let center = new google.maps.LatLng((latlon[0] - 0), (latlon[1] - 0));
            centers.push(center);
            let options = {
                center: center,
                zoom: 16,
                disableDefaultUI: true,
                styles: MAP_STYLES
            };
            let map = new google.maps.Map(dom, options);
            initMarker(center, map);
            return map;
        }
    }

    function centerMap(map, index) {
        map.setCenter(centers[index]);
    }

    function onWindowResize() {
        requestAnimationFrame(_ => maps.forEach(centerMap));
    }

    function init() {
        centers = [];
        maps = [].slice.call(document.getElementsByClassName(MAP_CLASS_NAME)).map(initMap);
        window.addEventListener('resize', onWindowResize);
    }

    function loadScript() {
        const script = document.createElement('script');
        script.addEventListener('load', init);
        script.type = 'text/javascript';
        document.body.appendChild(script);
        script.src = GM_SCRIPT_URL;
    }

    if (document.getElementsByClassName(MAP_CLASS_NAME).length > 0) {
        loadScript();
    }

};
