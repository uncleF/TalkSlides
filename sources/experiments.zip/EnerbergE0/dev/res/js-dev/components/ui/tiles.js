/* jshint browser:true */

'use strict';

module.exports = _ => {

    const TILES_ID = 'tiles';
    const TILES_HOVERED_SUFFIX = '-is-hoveredOver';
    const TILE_CLASS_NAME = 'tile';

    let tilesHovered;

    function checkTile(event) {
        return event.target.classList.contains(TILE_CLASS_NAME);
    }

    function onMouseOver(event) {
        if (checkTile(event)) {
            tiles.classList.add(tilesHovered);
        }
    }

    function onMouseOut(event) {
        if (checkTile(event)) {
            tiles.classList.remove(tilesHovered);
        }
    }

    let tiles = document.getElementById(TILES_ID);
    if (tiles) {
        tilesHovered = `${TILES_ID}${TILES_HOVERED_SUFFIX}`;
        tiles.addEventListener('mouseover', onMouseOver);
        tiles.addEventListener('mouseout', onMouseOut);
    }

};
