/* jshint browser:true */

'use strict';

module.exports = _ => {

    const galleryOverlay = require('ui/galleryOverlay');
    const gallerySwipe = require('ui/gallerySwipe');

    if (document.getElementById('gallery')) {
        galleryOverlay();
        gallerySwipe();
    }

};
