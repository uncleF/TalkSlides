/* jshint browser:true */

'use strict';

module.exports = id => {

    const device = require('device')();

    const INDEX_CLASS_LIST = 'page-index';

    const FEEDBACK_ID = 'feedback';
    const FEEDBACK_HOLDER_ID = 'feedbackForm';

    const REVEAL_DURATION = 1500;

    let form;
    let holder;
    let targetHeight;
    let targetScroll;
    let scrollHeight;
    let windowHeight;

    /* Animation */

    function cubicInOut(fraction) {
        return fraction < 0.5 ? 4 * Math.pow(fraction, 3) : (fraction - 1) * (2 * fraction - 2) * (2 * fraction - 2) + 1;
    }

    function runAnimation(startTime, duration, startScroll, deltaValue, task) {
        requestAnimationFrame(_ => {
            let fraction = (Date.now() - startTime) / duration;
            if (fraction < 1) {
                let currentValue = deltaValue * cubicInOut(fraction);
                revealFeedback(currentValue, startScroll);
                runAnimation(startTime, duration, startScroll, deltaValue, task);
            } else {
                revealFeedback(deltaValue, startScroll);
                cleanUp();
            }
        });
    }

    /* Actions */

    function revealFeedback(currentHeight, startScroll) {
        form.style.height = `${currentHeight}px`;
        window.scrollTo(0, startScroll + currentHeight);
    }

    function showFeedback() {
        runAnimation(Date.now(), REVEAL_DURATION, window.pageYOffset, targetHeight, revealFeedback);
    }

    function cleanUp() {
        form = null;
        holder = null;
        scrollHeight = null;
        windowHeight = null;
    }

    function measureHeights() {
        targetHeight = holder.clientHeight;
        targetScroll = holder.scrollTop;
        scrollHeight = document.documentElement.scrollHeight;
        windowHeight = window.innerHeight;
    }

    /* Initialization */

    function onScroll(event) {
        requestAnimationFrame(_ => {
            if (windowHeight + window.pageYOffset >= scrollHeight) {
                showFeedback();
                window.removeEventListener('scroll', onScroll);
                window.removeEventListener('resize', onResize);
            }
        });
    }

    function onResize() {
        requestAnimationFrame(measureHeights);
    }

    function initializeInteractions() {
        window.addEventListener('scroll', onScroll);
        window.addEventListener('resize', onResize);
    }

    form = document.getElementById(FEEDBACK_ID);

    if (form && document.body.classList.contains(INDEX_CLASS_LIST) && device.desktop()) {
        holder = document.getElementById(FEEDBACK_HOLDER_ID);
        measureHeights();
        initializeInteractions();
    } else {
        return false;
    }

};
