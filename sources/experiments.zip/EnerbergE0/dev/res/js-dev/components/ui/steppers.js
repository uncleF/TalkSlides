/* jshint browser:true */

'use strict';

module.exports = _ => {

    const stepper = require('ui/stepper');

    const STEPPER_CLASS_NAME = 'ammountStepper';

    function initStepper(dom) {
        stepper(dom);
    }

    const steppers = [].slice.call(document.getElementsByClassName(STEPPER_CLASS_NAME)).map(initStepper);

};
