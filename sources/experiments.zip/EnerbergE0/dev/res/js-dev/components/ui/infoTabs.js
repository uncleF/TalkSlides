/* jshint browser:true */

'use strict';

module.exports = _ => {

    const TAB_CLASS_NAME = 'tabLink';
    const TAB_ACTIVE_CLASS_NAME = 'tabLink-is-active';
    const TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME = 'tabContent-is-active';

    let activeTab;
    let activeContent;

    function deactivateActive() {
        activeTab.classList.remove(TAB_ACTIVE_CLASS_NAME);
        activeContent.classList.remove(TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME);
    }

    function activateNew(tab, content) {
        tab.classList.add(TAB_ACTIVE_CLASS_NAME);
        content.classList.add(TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME);
    }

    function onClick(event, link, content) {
        event.preventDefault();
        if (link !== activeTab) {
            if (activeTab) {
                deactivateActive();
            }
            activateNew(link, content);
            activeTab = link;
            activeContent = content;
        } else {
            deactivateActive();
            activeTab = null;
            activeContent = null;
        }
    }

    function addPair(link, index) {
        let contentId = link.getAttribute('href').replace('#', '');
        let content = document.getElementById(contentId);
        link.addEventListener('click', event => onClick(event, link, content));
        if (index === 0) {
            activeTab = link;
            activeContent = content;
        }
    }

    let tabObjects = document.getElementsByClassName(TAB_CLASS_NAME);

    if (tabObjects) {
        tabObjects = [].slice.call(tabObjects);
        tabObjects.forEach(addPair);
    }

};
