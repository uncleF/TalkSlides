/* jshint browser:true */

'use strict';

module.exports = _ => {

    const GALLERY_ID = 'gallery';
    const GALLERY_LINK_CLASS_NAME = 'galleryLink';
    const GALLERY_OVERLAY_ID = 'galleryOverlay';
    const GALLERY_OVERLAY_ACTIVE_CLASS_NAME = 'galleryOverlay-is-active';
    const GALLERY_OVERLAY_LOADING_CLASS_NAME = 'galleryOverlay-is-loading';
    const GALLERY_OVERLAY_IMAGE_ID = 'galleryFullImage';
    const GALLERY_OVERLAY_PREV_ID = 'galleryPrev';
    const GALLERY_OVERLAY_NEXT_ID = 'galleryNext';
    const GALLERY_OVERLAY_CLOSE_ID = 'galleryClose';
    const GALLERY_OVERLAY_NAV_DOT_CLASS_NAME = 'gNLink';
    const GALLERY_OVERLAY_NAV_DOT_ACTIVER_CLASS_NAME = 'gNLink-is-active';

    let activeIndex;

    function updateNavigation() {
        galleryDots[activeIndex].classList.add(GALLERY_OVERLAY_NAV_DOT_ACTIVER_CLASS_NAME);
    }

    function clearNavigation() {
        galleryDots[activeIndex].classList.remove(GALLERY_OVERLAY_NAV_DOT_ACTIVER_CLASS_NAME);
    }

    function showOverlay() {
        galleryOverlay.classList.add(GALLERY_OVERLAY_ACTIVE_CLASS_NAME);
    }

    function hideOverlay() {
        clearNavigation();
        galleryOverlay.classList.remove(GALLERY_OVERLAY_ACTIVE_CLASS_NAME);
    }

    function showLoadedImage(imageURL) {
        updateNavigation();
        galleryImage.src = imageURL;
        galleryOverlay.classList.remove(GALLERY_OVERLAY_LOADING_CLASS_NAME);
    }

    function loadImage(imageURL) {
        return new Promise((resolve, reject) => {
            let image = new Image();
            image.addEventListener('load', _ => resolve(imageURL));
            image.addEventListener('error', _ => reject(imageURL));
            image.src = imageURL;
        });
    }

    function showImage(imageURL) {
        galleryOverlay.classList.add(GALLERY_OVERLAY_LOADING_CLASS_NAME);
        loadImage(imageURL)
            .then(showLoadedImage);
    }

    function showPrevImage() {
        clearNavigation();
        activeIndex = activeIndex === 0 ? galleryLinks.length - 1 : activeIndex - 1;
        const imageURL = galleryLinks[activeIndex];
        showImage(imageURL);
    }

    function showNextImage() {
        clearNavigation();
        activeIndex = activeIndex === galleryLinks.length - 1 ? 0 : activeIndex + 1;
        const imageURL = galleryLinks[activeIndex];
        showImage(imageURL);
    }

    function onGalleryClick(event) {
        const target = event.target;
        if (target.classList.contains(GALLERY_LINK_CLASS_NAME)) {
            event.preventDefault();
            activeIndex = galleryLinks.indexOf(target);
            showOverlay();
            showImage(target.href);
        }
    }

    function onPrevClick(event) {
        event.preventDefault();
        showPrevImage();
    }

    function onNextClick(event) {
        event.preventDefault();
        showNextImage();
    }

    function onCloseClick(event) {
        event.preventDefault();
        hideOverlay();
    }

    function init() {
        gallery.addEventListener('click', onGalleryClick);
        galleryPrev.addEventListener('click', onPrevClick);
        galleryNext.addEventListener('click', onNextClick);
        galleryClose.addEventListener('click', onCloseClick);
    }

    const gallery = document.getElementById(GALLERY_ID);
    const galleryLinks = [].slice.call(gallery.getElementsByClassName(GALLERY_LINK_CLASS_NAME));
    const galleryOverlay = document.getElementById(GALLERY_OVERLAY_ID);
    const galleryImage = document.getElementById(GALLERY_OVERLAY_IMAGE_ID);
    const galleryNext = document.getElementById(GALLERY_OVERLAY_NEXT_ID);
    const galleryPrev = document.getElementById(GALLERY_OVERLAY_PREV_ID);
    const galleryClose = document.getElementById(GALLERY_OVERLAY_CLOSE_ID);
    const galleryDots = [].slice.call(galleryOverlay.getElementsByClassName(GALLERY_OVERLAY_NAV_DOT_CLASS_NAME));

    init();

};
