/* jshint browser:true */

'use strict';

module.exports = _ => {

    const SOCIAL_VK_ID = 'socialLink-FB';
    const SOCIAL_FB_ID = 'socialLink-VK';

    function onSocialClick(event) {
      event.preventDefault();
      const width = 626;
      const height = 305;
      const leftPosition = (window.screen.width / 2) - ((width / 2) + 10);
      const topPosition = (window.screen.height / 2) - ((height / 2) + 50);
      const windowFeatures = `status=no,height=${height},width=${width},resizable=no,left=${leftPosition},top=${topPosition},screenX=${leftPosition},screenY=${topPosition},toolbar=no,menubar=no,scrollbars=no,location=no,directories=no`;
      window.open(event.target.href, 'sharer', windowFeatures);
    }

    const socialFB = document.getElementById(SOCIAL_FB_ID);
    const socialVK = document.getElementById(SOCIAL_VK_ID);

    if (socialFB) {
        socialFB.addEventListener('click', onSocialClick);
    }

    if (socialVK) {
        socialVK.addEventListener('click', onSocialClick);
    }

}
