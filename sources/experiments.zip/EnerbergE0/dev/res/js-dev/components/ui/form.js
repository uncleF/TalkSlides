/* jshint browser:true */

'use strict';

module.exports = _ => {
    const fileInput = require('patterns/tx-fileInput');
    const steppers = require('ui/steppers');
    const phoneInput = require('ui/phoneInput');

    const FORM_ID = 'checkoutForm';
    const FORM_SUBMIT_ID = 'formSubmit';
    const FORM_ELEMENTS = '.formRequired';
    const FORM_SUBMIT_DISABLED_CLASS_NAME = 'formSubmit-is-disabled';
    const ELEMENT_ERROR_CLASS_NAME = 'formItem-has-error';

    let submit;
    let elements;

    fileInput.init('.formAttachment', 'Прикрепить файл', 'Удалить');
    steppers();
    phoneInput();

    function validateElement(element) {
        let value = element.value.trim();
        if (!value || value === '') {
            return false;
        } else {
            return true;
        }
    }

    function validateForm() {
        return elements.every(validateElement);
    }

    function lockForm() {
        submit.setAttribute('disabled', 'disabled');
        submit.classList.add(FORM_SUBMIT_DISABLED_CLASS_NAME);
    }

    function unlockForm() {
        submit.removeAttribute('disabled');
        submit.classList.remove(FORM_SUBMIT_DISABLED_CLASS_NAME);
    }

    function onElementFocus(event) {
        event.target.parentElement.classList.remove(ELEMENT_ERROR_CLASS_NAME);
    }

    function onElementInput(event) {
        if (validateForm()) {
            unlockForm();
        } else {
            lockForm();
        }
    }

    function subscribe() {
        form.addEventListener('input', onElementInput, true);
        form.addEventListener('keyup', onElementInput, true);
        form.addEventListener('change', onElementInput, true);
        form.addEventListener('focus', onElementFocus, true);
    }

    const form = document.getElementById(FORM_ID);
    if (form) {
        elements = [...form.querySelectorAll(FORM_ELEMENTS)];
        submit = document.getElementById(FORM_SUBMIT_ID);
        subscribe();
    }

};
