/* jshint browser:true */

'use strict';

module.exports = dom => {

    const eventManager = require('patterns/tx-event');

    const STEP = 1;

    let currentValue;

    function getCurrentValue() {
        currentValue = field.value - 0;
    }

    function triggerEvent() {
        eventManager.trigger(field, 'ast:change', true, 'UIEvent');
    }

    function updateValue(change) {
        let newValue = currentValue + change;
        currentValue = newValue < 1 ? 1 : newValue;
        field.value = currentValue;
        triggerEvent();
    }

    function onIncreaseClick(event) {
        event.preventDefault();
        updateValue(STEP);
    }

    function onDecreaseClick(event) {
        event.preventDefault();
        updateValue(-STEP);
    }

    function onChange() {
        getCurrentValue();
        triggerEvent();
    }

    let field = dom.getElementsByClassName('aSField')[0];
    let increase = dom.getElementsByClassName('aSIncrease')[0];
    let decrease = dom.getElementsByClassName('aSDecrease')[0];

    increase.addEventListener('click', onIncreaseClick);
    decrease.addEventListener('click', onDecreaseClick);
    field.addEventListener('change', onChange);
    field.addEventListener('input', onChange);
    getCurrentValue();

};
