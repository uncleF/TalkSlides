/* globals describe:false, it:false */

var rewire = require('rewire');
var expect = require('chai').expect;
