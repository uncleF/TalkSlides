module.exports = {
  'analyzecss': 'grunt-analyze-css',
  'removelogging': 'grunt-remove-logging',
  'scsslint': 'grunt-scss-lint',
  'sprite': 'grunt-spritesmith'
};
