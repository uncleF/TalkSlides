module.exports = (grunt, options) => {

    var project = options.project;
    var helpers = options.helpers;

    return {
        service: {
            cwd: project.res.js.devDir,
            src: `${project.res.js.service}.js`,
            dest: project.res.js.dir,
            expand: true
        },
        build: {
            cwd: project.dir,
            src: [
                '**/*.*',
                `!${project.res.templates.dir.replace(project.dir, '')}/**`,
                `!${project.res.css.sass.replace(project.dir, '')}/**`,
                ...helpers.dontCopy,
                ...helpers.sprites
            ],
            dest: project.build.dir,
            expand: true
        },
        site: {
            cwd: `${project.build.dir}${project.res.dir.replace(project.dir, '')}`,
            src: '**/*.*',
            dest: project.res.siteDir,
            expand: true
        },
        siteDev: {
            cwd: project.res.dir,
            src: [
                '**/*.{js,css}',
                '!**/*.min.{js,css}',
                ...helpers.dontCopy
            ],
            dest: project.res.siteDir,
            expand: true,
            rename: function(dest, src) {
              return `${dest}${src.replace(/\.(js|css)/, '.min.$1')}`;
            }
        },
        meta: {
            cwd: project.meta,
            src: ['**/*.*'],
            dest: project.build.dir,
            expand: true
        }
    };

};
