'use strict';

module.exports = (grunt) => {

  grunt.registerTask('watch-project', [
    'concurrent'
  ]);

};
