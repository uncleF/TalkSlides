(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var nanoajax = require('nanoajax');
    var eventManager = require('patterns/tx-event');

    var ADD_ID = 'addCart';
    var ADD_URL = '/api/cart/add';
    var ITEM_ID_ID = 'itemID';
    var ITEM_TYPE_ID = 'itemType';
    var ITEM_QUANTITY_ID = 'itemQuantity';

    var REMOVE_URL = '/api/cart/delete';
    var REMOVE_CART_LINK_CLASS_NAME = 'cartListItemRemove';
    var REMOVE_TABLE_LINK_CLASS_NAME = 'cartRemoveItem';

    var UPDATE_URL = '/api/cart';

    var CART_ID = 'cart';
    var CART_LIST_ID = 'cartList';
    var CART_COUNTER_ID = 'cartCount';
    var CART_QUANTITY_ID = 'cartTotalQuantity';
    var CART_SUM_ID = 'cartTotalSum';

    var TABLE_ID = 'cartTable';
    var TABLE_QUANTITY_ID = 'cartTableTotalQuantity';
    var TABLE_SUM_ID = 'cartTableTotalSum';
    var ADD_ACCESSORY_CLASS_NAME = 'cartAdd';
    var ACCESSORY_SUB_CLASS_NAME = 'sideShopNavLink-accessory';

    var CLEAR_URL = '/api/cart/clear';
    var CLEAR_ID = 'cartClear';

    var AMMOUNT_CLASS_NAME = 'aSField';
    var AMMOUNT_DELAY = 200;

    var add = void 0;
    var itemID = void 0;
    var itemType = void 0;
    var itemQuantity = void 0;

    var cart = void 0;
    var cartList = void 0;
    var cartCounter = void 0;
    var cartQuantity = void 0;
    var cartSum = void 0;
    var cartData = void 0;

    var table = void 0;
    var tableQuantity = void 0;
    var tableSum = void 0;
    var accessorySub = void 0;

    var clear = void 0;

    var ammountDelay = void 0;

    function collectAddItemData() {
        return 'product_id=' + itemID.value + '&product_type=' + itemType.value + '&quantity=' + itemQuantity.value;
    }

    function collectRemoveItemData(element) {
        return 'product_id=' + element.getAttribute('data-id') + '&product_type=' + element.getAttribute('data-type');
    }

    function collectUpdateItemData(element) {
        return 'product_id=' + element.getAttribute('data-id') + '&product_type=' + element.getAttribute('data-type') + '&quantity=' + element.value;
    }

    function getTopCartItem(items, item) {
        var listItem = '<li class="cartListItem">\n                              <img src="' + item.product.image + '" class="cartListImage" alt="">\n                              <span class="cartListItemName">' + item.product.manufacturer.name + ' ' + item.product.name + '</span>\n                              <a href="#" class="cartListItemRemove">\u0423\u0434\u0430\u043B\u0438\u0442\u044C</a>\n                          </li>';
        return {
            list: items.list + listItem,
            count: items.count + (item.quantity - 0),
            sum: items.sum + (item.quantity - 0) * (item.product.cost - 0)
        };
    }

    function numberWithSpaces(number) {
        return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    }

    function updateTopCart(data) {
        if (cart) {
            if (data.count > 0) {
                cartCounter.textContent = data.count;
                cartQuantity.textContent = data.items.count + ' \u0448\u0442';
                cartSum.innerHTML = numberWithSpaces(data.items.sum) + ' \u0440';
                cartList.innerHTML = data.items.list;
            } else {
                cartCounter.textContent = '';
                cartQuantity.textContent = 0;
                cartSum.textContent = 0;
                cartList.innerHTML = '';
            }
        }
    }

    function updateContentCart(data) {
        if (table) {
            if (data.count > 0) {
                tableQuantity.textContent = data.items.count + ' \u0448\u0442';
                tableSum.innerHTML = numberWithSpaces(data.items.sum) + ' \u0440';
            } else {
                tableQuantity.textContent = 0;
                tableSum.innerHTML = 0;
            }
        }
    }

    function onResponse(code) {
        if (code === 200) {
            updateCart();
        }
    }

    function onUpdateResponse(code, response) {
        if (code === 200) {
            var json = JSON.parse(response);
            cartData = {
                count: json.length,
                items: json.reduce(getTopCartItem, { list: '', count: 0, sum: 0 })
            };
            updateTopCart(cartData);
            updateContentCart(cartData);
        }
    }

    function onClearResponse(code) {}

    function sendAddItem(data) {
        nanoajax.ajax({
            url: ADD_URL,
            method: 'POST',
            body: data
        }, onResponse);
    }

    function sendRemoveItem(data) {
        nanoajax.ajax({
            url: REMOVE_URL,
            method: 'POST',
            body: data
        }, onResponse);
    }

    function sendUpdateCart() {
        nanoajax.ajax({
            url: UPDATE_URL,
            method: 'GET'
        }, onUpdateResponse);
    }

    function sendClearCart() {
        nanoajax.ajax({
            url: CLEAR_URL,
            method: 'POST'
        }, onClearResponse);
    }

    function sendUpdateItem(data) {
        nanoajax.ajax({
            url: ADD_URL,
            method: 'POST',
            body: data
        }, onResponse);
    }

    function updateCart() {
        sendUpdateCart();
    }

    function addItem() {
        var data = collectAddItemData();
        sendAddItem(data);
    }

    function removeCartItem(link) {
        var data = collectRemoveItemData(link);
        link.parentElement.remove();
        if (table) {
            var tableLink = [].slice.call(table.getElementsByClassName(REMOVE_TABLE_LINK_CLASS_NAME)).filter(function (removeLink) {
                var attrID = link.getAttribute('data-id') === removeLink.getAttribute('data-id');
                var attrType = link.getAttribute('data-type') === removeLink.getAttribute('data-type');
                return attrID && attrType;
            });
            tableLink[0].parentElement.parentElement.remove();
        }
        sendRemoveItem(data);
    }

    function removeTableItem(link) {
        var data = collectRemoveItemData(link);
        link.parentElement.parentElement.remove();
        if (cart) {
            var cartLink = [].slice.call(cart.getElementsByClassName(REMOVE_CART_LINK_CLASS_NAME)).filter(function (removeLink) {
                var attrID = link.getAttribute('data-id') === removeLink.getAttribute('data-id');
                var attrType = link.getAttribute('data-type') === removeLink.getAttribute('data-type');
                return attrID && attrType;
            });
            cartLink[0].parentElement.remove();
        }
        sendRemoveItem(data);
    }

    function clearCart() {
        if (cartList) {
            cartCounter.textContent = '';
            cartQuantity.textContent = 0;
            cartSum.textContent = 0;
            cartList.innerHTML = '';
        }
        if (table) {
            tableQuantity.textContent = 0;
            tableSum.innerHTML = 0;
            table.getElementsByTagName('tbody')[0].innerHTML = '';
        }
        sendClearCart();
    }

    function updateItemAmmount(target) {
        var data = collectUpdateItemData(target);
        sendUpdateItem(data);
    }

    function onAddClick(event) {
        event.preventDefault();
        addItem();
    }

    function onCartClick(event) {
        var target = event.target;
        if (target.className === REMOVE_CART_LINK_CLASS_NAME) {
            event.preventDefault();
            removeCartItem(target);
        }
    }

    function onTableClick(event) {
        var target = event.target;
        if (target.className === REMOVE_TABLE_LINK_CLASS_NAME) {
            event.preventDefault();
            removeTableItem(target);
        } else if (target.className === ADD_ACCESSORY_CLASS_NAME) {
            event.preventDefault();
            eventManager.trigger(accessorySub, 'click');
        }
    }

    function onTableChange(event) {
        var target = event.target;
        if (target.className === AMMOUNT_CLASS_NAME) {
            event.preventDefault();
            clearTimeout(ammountDelay);
            ammountDelay = setTimeout(function (_) {
                return updateItemAmmount(target);
            }, AMMOUNT_DELAY);
        }
    }

    function onClearClick(event) {
        event.preventDefault();
        clearCart();
    }

    add = document.getElementById(ADD_ID);
    cart = document.getElementById(CART_ID);
    table = document.getElementById(TABLE_ID);
    clear = document.getElementById(CLEAR_ID);

    if (add) {
        itemID = document.getElementById(ITEM_ID_ID);
        itemType = document.getElementById(ITEM_TYPE_ID);
        itemQuantity = document.getElementById(ITEM_QUANTITY_ID);
        add.addEventListener('click', onAddClick);
    }

    if (cart) {
        cartCounter = document.getElementById(CART_COUNTER_ID);
        cartList = document.getElementById(CART_LIST_ID);
        cartQuantity = document.getElementById(CART_QUANTITY_ID);
        cartSum = document.getElementById(CART_SUM_ID);
        cart.addEventListener('click', onCartClick);
    }

    if (table) {
        tableQuantity = document.getElementById(TABLE_QUANTITY_ID);
        tableSum = document.getElementById(TABLE_SUM_ID);
        accessorySub = document.getElementsByClassName(ACCESSORY_SUB_CLASS_NAME)[0];
        table.addEventListener('click', onTableClick);
        table.addEventListener('ast:change', onTableChange, false);
    }

    if (clear) {
        clear.addEventListener('click', onClearClick);
    }
};

},{"nanoajax":34,"patterns/tx-event":8}],2:[function(require,module,exports){

/* jshint browser:true */

'use strict';

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

module.exports = function (_) {

    var nanoajax = require('nanoajax');

    var URL = '/api/question';

    var FEEDBACK_FORM_ID = 'feedback';
    var FEEDBACK_SUCESS_ID = 'feedbackSuccessMessage';
    var FEEDBACK_SUCESS_ACTIVE_CLASS_NAME = 'feedbackSuccessMessage-is-active';
    var FEEDBACK_FAIL_ID = 'feedbackFailMessage';
    var FEEDBACK_FAIL_ACTIVE_CLASS_NAME = 'feedbackFailMessage-is-active';
    var FEEDBACK_RETRY_ID = 'feedbackRetry';
    var FEEDBACK_ELEMENTS = '.feedbackText, .feedbackField';
    var FEEDBACK_SUBMIT_ID = 'feedbackSubmit';
    var FEEDBACK_SUBMIT_DISABLED_CLASS_NAME = 'feedbackSubmit-is-disabled';
    var ELEMENT_ERROR_CLASS_NAME = 'feedbackItem-has-error';

    var TOKEN_ID = 'csrf';

    var elements = void 0;
    var success = void 0;
    var fail = void 0;
    var retry = void 0;
    var submit = void 0;

    function hideSuccess() {
        feedback.reset();
        success.classList.remove(FEEDBACK_SUCESS_ACTIVE_CLASS_NAME);
    }

    function showSuccess() {
        success.classList.add(FEEDBACK_SUCESS_ACTIVE_CLASS_NAME);
        setTimeout(hideSuccess, 2000);
    }

    function hideFail() {
        fail.classList.remove(FEEDBACK_FAIL_ACTIVE_CLASS_NAME);
    }

    function showFail() {
        fail.classList.add(FEEDBACK_FAIL_ACTIVE_CLASS_NAME);
    }

    function validateElement(element) {
        var value = element.value.trim();
        if (!value || value === '') {
            return false;
        } else {
            return true;
        }
    }

    function validateForm() {
        return elements.every(validateElement);
    }

    function onResponse(code) {
        if (code === 200) {
            showSuccess();
        } else {
            showFail();
        }
    }

    function formData() {
        var data = [];
        var id = feedback.getAttribute('data-item-id');
        elements.forEach(function (element) {
            return data.push(element.name + '=' + element.value.trim());
        });
        data.push('url=' + window.location.href);
        if (id && id !== '') {
            data.push('product_id=' + id);
        }
        return data.join('&');
    }

    function sendForm() {
        nanoajax.ajax({
            url: URL,
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': document.getElementById(TOKEN_ID).getAttribute('content') },
            body: formData()
        }, onResponse);
    }

    function markElement(element) {
        if (!element.value.trim() || element.value.trim() === '') {
            element.parentElement.classList.add(ELEMENT_ERROR_CLASS_NAME);
        }
    }

    function markInvalid() {
        elements.forEach(markElement);
    }

    function lockForm() {
        submit.setAttribute('disabled', 'disabled');
        submit.classList.add(FEEDBACK_SUBMIT_DISABLED_CLASS_NAME);
    }

    function unlockForm() {
        submit.removeAttribute('disabled');
        submit.classList.remove(FEEDBACK_SUBMIT_DISABLED_CLASS_NAME);
    }

    function onFormSubmit(event) {
        event.preventDefault();
        if (validateForm()) {
            sendForm();
        } else {
            markInvalid();
        }
    }

    function onElementFocus(event) {
        event.target.parentElement.classList.remove(ELEMENT_ERROR_CLASS_NAME);
    }

    function onElementInput(event) {
        if (validateForm()) {
            unlockForm();
        } else {
            lockForm();
        }
    }

    function onRetryClick(event) {
        event.preventDefault();
        hideFail();
    }

    function subscribe() {
        feedback.addEventListener('submit', onFormSubmit);
        feedback.addEventListener('input', onElementInput, true);
        feedback.addEventListener('keyup', onElementInput, true);
        feedback.addEventListener('change', onElementInput, true);
        feedback.addEventListener('focus', onElementFocus, true);
        retry.addEventListener('click', onRetryClick);
    }

    var feedback = document.getElementById(FEEDBACK_FORM_ID);
    if (feedback) {
        elements = [].concat(_toConsumableArray(feedback.querySelectorAll(FEEDBACK_ELEMENTS)));
        success = document.getElementById(FEEDBACK_SUCESS_ID);
        fail = document.getElementById(FEEDBACK_FAIL_ID);
        retry = document.getElementById(FEEDBACK_RETRY_ID);
        submit = document.getElementById(FEEDBACK_SUBMIT_ID);
        subscribe();
    }
};

},{"nanoajax":34}],3:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var PHONE_THRESHOLD = 980;

    function phone() {
        return window.innerWidth <= PHONE_THRESHOLD;
    }

    function desktop() {
        return window.innerWidth > PHONE_THRESHOLD;
    }

    return {
        phone: phone,
        desktop: desktop
    };
};

},{}],4:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (dom) {

    var eventManager = require('patterns/tx-event');

    var FILTER_SELECT_CLASS_NAME = 'filterSelect';

    var conditions = void 0;

    function transmitEvent() {
        eventManager.trigger(document, 'fltr:update', false, 'UIEvent', { conditions: conditions });
    }

    function updateCondition(select) {
        var spread = select.dataset.spread;
        var value = void 0;
        if (spread) {
            var connectedValue = document.getElementById(spread).value;
            value = select.dataset.hasOwnProperty('min') ? [select.value, connectedValue] : [connectedValue, select.value];
        } else {
            value = select.value;
        }
        return {
            name: select.dataset.key,
            value: value
        };
    }

    function updateConditions() {
        conditions = filterSelects.map(updateCondition);
    }

    function onChange() {
        updateConditions();
        transmitEvent();
    }

    function init() {
        filterElement.addEventListener('change', onChange, true);
        updateConditions();
    }

    var filterElement = dom;
    var filterSelects = [].slice.call(dom.getElementsByClassName(FILTER_SELECT_CLASS_NAME));

    init();

    return {
        trigger: onChange
    };
};

},{"patterns/tx-event":8}],5:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var eventManager = require('patterns/tx-event');

    var TAB_CLASS_NAME = 'filterTabLink';
    var TAB_ACTIVE_CLASS_NAME = 'filterTabLink-is-active';
    var TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME = 'filter-is-active';

    var activeTab = void 0;
    var activeContent = void 0;

    function transmitEvent() {
        eventManager.trigger(document, 'fltr:reset', false, 'UIEvent');
    }

    function deactivateActive() {
        activeTab.classList.remove(TAB_ACTIVE_CLASS_NAME);
        activeContent.classList.remove(TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME);
    }

    function activateNew(tab, content) {
        tab.classList.add(TAB_ACTIVE_CLASS_NAME);
        content.classList.add(TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME);
    }

    function onClick(event, link, content) {
        event.preventDefault();
        if (link !== activeTab) {
            if (activeTab) {
                deactivateActive();
            }
            activateNew(link, content);
            activeTab = link;
            activeContent = content;
            transmitEvent();
        }
    }

    function addPair(link, index) {
        var contentId = link.getAttribute('href').replace('#', '');
        var content = document.getElementById(contentId);
        link.addEventListener('click', function (event) {
            return onClick(event, link, content);
        });
        if (index === 0) {
            activeTab = link;
            activeContent = content;
        }
    }

    var tabObjects = document.getElementsByClassName(TAB_CLASS_NAME);

    if (tabObjects) {
        tabObjects = [].slice.call(tabObjects);
        tabObjects.forEach(addPair);
    }
};

},{"patterns/tx-event":8}],6:[function(require,module,exports){

/* jshint browser:true */

'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports = function (_) {

    var filter = require('filter/filter');

    var FILTER_CLASS_NAME = 'filter';
    var CATALOG_ITEM_CLASS_NAME = 'catalogTableItem';
    var CATALOG_ITEM_HIDDEN_CLASS_NAME = 'catalogTableItem-is-hidden';
    var CATALOG_ITEM_EVEN_CLASS_NAME = 'catalogTableItem-is-even';
    var CATALOG_ITEM_ODD_CLASS_NAME = 'catalogTableItem-is-odd';
    var FILTER_MODEL_ID = 'filter-model';
    var FILTER_TECH_ID = 'filter-tech';
    var CATALOG_LINK_CLASS = 'catalogTableLink';

    var catalogItemElements = void 0;
    var catalogItems = void 0;

    var filters = void 0;
    var currentConditions = void 0;

    function createItem(itemElement) {
        return {
            dom: itemElement,
            conditions: itemElement.dataset
        };
    }

    function filterItem(item) {
        item.dom.classList.remove(CATALOG_ITEM_ODD_CLASS_NAME, CATALOG_ITEM_EVEN_CLASS_NAME);
        var passes = currentConditions.every(function (filterItem) {
            if (_typeof(filterItem.value) === 'object') {
                var value = item.conditions[filterItem.name] - 0;
                var min = filterItem.value[0] - 0;
                var max = filterItem.value[1] - 0;
                return value >= min && value <= max;
            } else {
                var values = item.conditions[filterItem.name].split(',');
                return values.indexOf(filterItem.value) > -1;
            }
        });
        if (!passes) {
            item.dom.classList.add(CATALOG_ITEM_HIDDEN_CLASS_NAME);
        } else {
            item.dom.classList.remove(CATALOG_ITEM_HIDDEN_CLASS_NAME);
        }
    }

    function selectFiltered(item) {
        return !item.dom.classList.contains(CATALOG_ITEM_HIDDEN_CLASS_NAME);
    }

    function paintFiltered(item, index) {
        if (index % 2 !== 0) {
            item.dom.classList.add(CATALOG_ITEM_EVEN_CLASS_NAME);
        } else {
            item.dom.classList.add(CATALOG_ITEM_ODD_CLASS_NAME);
        }
    }

    function updateLinks(item) {
        var link = item.dom.getElementsByClassName(CATALOG_LINK_CLASS)[0];
        link.href = link.href.replace(/\?.*/, '');
        link.href += '?modelId=' + filterModel.value;
    }

    function filterCatalog() {
        catalogItems.forEach(filterItem);
        catalogItems.filter(selectFiltered).forEach(paintFiltered);
        if (filterModel) {
            catalogItems.filter(selectFiltered).forEach(updateLinks);
        }
    }

    function updateOptions(value) {
        var options = [].slice.call(filterModel.getElementsByTagName('option'));
        options.forEach(function (option) {
            var values = option.getAttribute('data-tech').split(',');
            if (values.indexOf(value) > -1) {
                option.removeAttribute('disabled');
                option.classList.remove('filterOption-is-disabled');
            } else {
                option.setAttribute('disabled', 'disabled');
                option.classList.add('filterOption-is-disabled');
            };
        });
        options[0].setAttribute('selected', 'selected');
    }

    function onFilterReset() {
        catalogItemElements.forEach(function (element) {
            return element.classList.remove(CATALOG_ITEM_HIDDEN_CLASS_NAME);
        });
        currentConditions = [];
    }

    function onFilterUpdate(event) {
        if (filterTech) {
            updateOptions(filterTech.value);
        }
        currentConditions = event.data.conditions;
        filterCatalog();
    }

    function init() {
        filters = filterElements.map(filter);
        document.addEventListener('fltr:update', onFilterUpdate);
        document.addEventListener('fltr:reset', onFilterReset);
        filters[0].trigger();
    }

    var filterElements = [].slice.call(document.getElementsByClassName(FILTER_CLASS_NAME));
    var filterModel = document.getElementById(FILTER_MODEL_ID);
    var filterTech = document.getElementById(FILTER_TECH_ID);

    if (filterElements.length > 0) {
        catalogItemElements = [].slice.call(document.getElementsByClassName(CATALOG_ITEM_CLASS_NAME));
        catalogItems = catalogItemElements.map(createItem);
        init();
    }
};

},{"filter/filter":4}],7:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (html) {
  var element = document.createElement('div');
  element.innerHTML = html;
  return element.firstChild;
};

},{}],8:[function(require,module,exports){

/* jshint browser:true */

'use strict';

/* Event Data */

function setData(event, data) {
  event.data = data;
  return event;
}

function getData(event) {
  return event.data;
}

/* Event Binding */

function bind(object, type, callback) {
  object.addEventListener(type, callback);
}

function unbind(object, type, callback) {
  object.removeEventListener(type, callback);
}

/* Event Trigger */

function triggerCreateEvent(object, eventName, propagate, eventType, data) {
  var event = document.createEvent(eventType);
  if (data) {
    setData(event, data);
  }
  event.initEvent(eventName, propagate, false);
  object.dispatchEvent(event);
}

function triggerCreateEventObject(object, eventName, propagate, data) {
  var event = document.createEventObject();
  if (data) {
    setData(event, data);
  }
  object.fireEvent('on' + eventName, event);
}

function trigger(object, eventName, propagate, eventType, data) {
  propagate = propagate || false;
  eventType = eventType || 'MouseEvents';
  if (document.createEvent) {
    triggerCreateEvent(object, eventName, propagate, eventType, data);
  } else {
    triggerCreateEventObject(object, eventName, propagate, data);
  }
}

/* Event Target */

function target(event) {
  return event.target;
}

/* Interface */

exports.getData = getData;
exports.bind = bind;
exports.unbind = unbind;
exports.trigger = trigger;
exports.target = target;

},{}],9:[function(require,module,exports){

/* jshint browser:true */

'use strict';

var eventTool = require('./tx-event');

var WRAP_CLASS_NAME_SUFFIX = '-wrap';
var VALUE_CLASS_NAME_SUFFIX = '-value';
var BUTTON_CLASS_NAME_SUFFIX = '-button';
var REMOVE_CLASS_NAME_SUFFIX = '-remove';
var WRAPED_CLASS_NAME_SUFFIX = '-is-wrapped';
var FILLED_CLASS_NAME_SUFFIX = '-has-file';

/* HTML */

function createWrap(className) {
    var element = document.createElement('div');
    element.className = '' + className + WRAP_CLASS_NAME_SUFFIX;
    return element;
}

function createValue(className) {
    var element = document.createElement('div');
    element.className = '' + className + VALUE_CLASS_NAME_SUFFIX;
    return element;
}

function createButton(className, classNameSuffix, text) {
    var element = document.createElement('a');
    element.href = '#';
    element.textContent = text;
    element.className = '' + className + classNameSuffix;
    return element;
}

function wrapInput(className, input, wrap, value, attach, remove) {
    var parent = input.parentNode;
    wrap.appendChild(value);
    wrap.appendChild(remove);
    wrap.appendChild(attach);
    parent.insertBefore(wrap, input);
    input.classList.add('' + className + WRAPED_CLASS_NAME_SUFFIX);
    wrap.appendChild(input);
}

/* Field Constructor */

function fileInput(field, textAttach, textRemove) {

    var input;
    var className;
    var wrap;
    var value;
    var buttonAttach;
    var buttonRemove;

    /* Field Interactions */

    function onChange(event) {
        var newValue = input.value.split('\\')[2];
        if (newValue) {
            value.textContent = newValue;
            wrap.classList.add('' + className + FILLED_CLASS_NAME_SUFFIX);
        } else {
            value.textContent = '';
            wrap.classList.remove('' + className + FILLED_CLASS_NAME_SUFFIX);
        }
        console.log(input.value);
    }

    function onButtonClick(event) {
        event.preventDefault();
        eventTool.trigger(input, 'click');
    }

    function onRemoveClick(event) {
        event.preventDefault();
        input.value = '';
        value.textContent = '';
        wrap.classList.remove('' + className + FILLED_CLASS_NAME_SUFFIX);
    }

    function initInteractions() {
        eventTool.bind(input, 'change', onChange);
        eventTool.bind(buttonAttach, 'click', onButtonClick);
        eventTool.bind(buttonRemove, 'click', onRemoveClick);
    }

    function removeInteractions() {
        eventTool.unbind(input, 'change', onChange);
        eventTool.unbind(buttonAttach, 'click', onButtonClick);
        eventTool.unbind(buttonRemove, 'click', onRemoveClick);
    }

    /* Field Initialization */

    function initValues() {
        input = field;
        className = input.classList.item(0);
        wrap = createWrap(className);
        value = createValue(className);
        buttonAttach = createButton(className, BUTTON_CLASS_NAME_SUFFIX, textAttach);
        buttonRemove = createButton(className, REMOVE_CLASS_NAME_SUFFIX, textRemove);
    }

    function initField() {
        initValues();
        wrapInput(className, input, wrap, value, buttonAttach, buttonRemove);
        initInteractions();
    }

    function removeValues() {
        input = null;
        className = null;
        wrap = null;
        value = null;
        buttonAttach = null;
        buttonRemove = null;
    }

    function destroyField() {
        removeInteractions();
        removeValues();
    }

    initField();

    /* Field Interface */

    return {
        destroy: destroyField
    };
}

/* Initialization */

function init(selector, textAttach, textRemove) {
    var fields = [].slice.call(document.querySelectorAll(selector));
    fields.forEach(function (field) {
        return fileInput(field, textAttach, textRemove);
    });
}

function destroy(fields) {
    fields.forEach(function (field) {
        return field.destroy();
    });
}

/* Interface */

exports.init = init;
exports.destroy = destroy;

},{"./tx-event":8}],10:[function(require,module,exports){

/* jshint browser:true */

'use strict';

var FontFaceObserver = require('fontfaceobserver/fontfaceobserver.js');

var LOADED_SUFFIX = '-is-loaded';

function getFontClassName(fontName) {
  var firstCharacter = fontName.charAt(0).toLowerCase();
  var noSpaces = fontName.replace(/ /g, '');
  return '' + firstCharacter + noSpaces.slice(1, noSpaces.length) + LOADED_SUFFIX;
}

function fontPromise(font) {
  var rest = new FontFaceObserver(font);
  rest.load().then(function (loadedFont) {
    document.body.classList.add(getFontClassName(loadedFont.family));
  });
}

module.exports = function (fontCritical, fontsRest) {
  var critical = new FontFaceObserver(fontCritical);
  critical.load().then(function (loadedFont) {
    document.body.classList.add(getFontClassName(loadedFont.family));
    if (fontsRest) {
      fontsRest.forEach(fontPromise);
    }
  });
};

},{"fontfaceobserver/fontfaceobserver.js":32}],11:[function(require,module,exports){

/* jshint browser:true */

'use strict';

var SLIDE_THRESHOLD = 15;
var NEXT_SHIFT = 50;

var SLIDER_CLASS_NAME = 'slider';
var SLIDER_FIXING_CLASS_NAME = SLIDER_CLASS_NAME + '-is-fixing';
var SLIDER_CHANGING_CLASS_NAME = SLIDER_CLASS_NAME + '-is-changing';
var SLIDER_EVENT = 'swipe';
var SLIDE_ACTIVE_CLASS_NAME_SUFFIX = '-is-active';
var DOT_NAVIGATION_CLASS_NAME = 'js-dotsNavigation';
var DOT_CLASS_NAME = 'js-dotsPage';
var DOT_ACTIVE_CLASS_NAME = '' + DOT_CLASS_NAME + SLIDE_ACTIVE_CLASS_NAME_SUFFIX;

var eventTool = require('./tx-event');
var createNode = require('./tx-createNode');
var transition = require('./tx-transition')();
var translateGallery = require('./tx-translate').css;

/* Dots */

function generateNavigationDots(size, pageClassName) {
    var navigationDots = '';
    for (var index = 0; index < size; index += 1) {
        navigationDots += index === 0 ? '<li class="' + pageClassName + ' ' + pageClassName + SLIDE_ACTIVE_CLASS_NAME_SUFFIX + ' ' + DOT_ACTIVE_CLASS_NAME + ' ' + DOT_CLASS_NAME + '"></li>' : '<li class="' + pageClassName + ' ' + DOT_CLASS_NAME + '"></li>';
    }
    return navigationDots;
}

function dots(size, listClassName, pageClassName) {
    var navigation = '<ol class="' + listClassName + ' ' + DOT_NAVIGATION_CLASS_NAME + '">' + generateNavigationDots(size, pageClassName) + '</ol>';
    return createNode(navigation);
}

/* Slider Constructor */

function init(object, navigationObject, pageClassName) {

    var slider;
    var sliderDots;
    var sliderDotClassName;
    var sliderDotActiveClassName;

    var sliderMax;
    var activeSlideIndex;
    var activeSlideDot;

    var pointStartX;
    var pointShift;
    var pointDiffX;
    var positionStart;

    var animationFrame;

    /* Get */

    function getSlider() {
        return slider;
    }

    function getSliderDots() {
        return sliderDots;
    }

    function getSliderDot(index) {
        return getSliderDots()[index];
    }

    function getSliderDotClassName() {
        return sliderDotClassName;
    }

    function getSliderDotActiveClassName() {
        return sliderDotActiveClassName;
    }

    function getSliderMax() {
        return sliderMax;
    }

    function getActiveSlideIndex() {
        return activeSlideIndex;
    }

    function getActiveSlideDot() {
        return activeSlideDot;
    }

    function getPointStartX() {
        return pointStartX;
    }

    function getPointShift() {
        return pointShift;
    }

    function getPointDiffX() {
        return pointDiffX;
    }

    function getPositionStart() {
        return positionStart;
    }

    function getAnimationFrame(frame) {
        return animationFrame;
    }

    /* Set */

    function setSlider() {
        slider = object;
    }

    function setSliderDots() {
        sliderDots = navigationObject.getElementsByClassName(getSliderDotClassName());
    }

    function setSliderDotClassName() {
        sliderDotClassName = pageClassName;
        sliderDotActiveClassName = '' + pageClassName + SLIDE_ACTIVE_CLASS_NAME_SUFFIX;
    }

    function setSliderMax() {
        sliderMax = sliderDots.length - 1;
    }

    function setActiveSlideIndex(index) {
        activeSlideIndex = index;
    }

    function setActiveSlideDot() {
        activeSlideDot = getSliderDot(getActiveSlideIndex());
    }

    function setPointStartX(start) {
        pointStartX = start;
    }

    function setPointShift(shift) {
        pointShift = shift;
    }

    function setPointDiffX(diff) {
        pointDiffX = diff;
    }

    function setPositionStart(position) {
        positionStart = position;
    }

    function setAnimationFrame(frame) {
        animationFrame = frame;
    }

    /* Slider Utilities */

    function updateDots() {
        getActiveSlideDot().classList.remove(getSliderDotActiveClassName(), DOT_ACTIVE_CLASS_NAME);
        setActiveSlideDot();
        getActiveSlideDot().classList.add(getSliderDotActiveClassName(), DOT_ACTIVE_CLASS_NAME);
    }

    function calculatePositions() {
        if (getActiveSlideIndex() === 0 && getPointDiffX() > 0) {
            setPointShift(4);
        } else if (getActiveSlideIndex() === getSliderMax() && getPointDiffX() < 0) {
            setPointShift(4);
        }
    }

    function calculateCompleteDistance() {
        return -100 * getActiveSlideIndex() + '%';
    }

    function calculateSlideDistance() {
        var correction = getPointDiffX() < 0 ? SLIDE_THRESHOLD : -SLIDE_THRESHOLD;
        return getPositionStart() + (getPointDiffX() + correction) / getPointShift() + 'px';
    }

    function translateSlider(distance) {
        getSlider().style.transform = translateGallery('x', distance).transform;
    }

    function shiftSlider() {
        calculatePositions();
        translateSlider(calculateSlideDistance());
    }

    function finalizeSlide() {
        getSlider().classList.remove(SLIDER_FIXING_CLASS_NAME, SLIDER_CHANGING_CLASS_NAME);
        eventTool.unbind(slider, transition, finalizeSlide);
    }

    function updateInteractionParameters(event) {
        var startPoint = event ? event.touches[0].pageX : 0;
        setPointStartX(startPoint);
        setPointShift(1);
        setPointDiffX(0);
        setPositionStart(getSlider().getBoundingClientRect().left);
    }

    function preventClick(event) {
        if (event) {
            event.preventDefault();
        }
    }

    function increaseActiveSlideIndex() {
        setActiveSlideIndex(getActiveSlideIndex() + 1);
    }

    function deincreaseActiveSlideIndex() {
        setActiveSlideIndex(getActiveSlideIndex() - 1);
    }

    function slidingForward() {
        return getPointDiffX() < -NEXT_SHIFT && getActiveSlideIndex() !== getSliderMax();
    }

    function slidingBack() {
        return getPointDiffX() > NEXT_SHIFT && getActiveSlideIndex() !== 0;
    }

    function updateIndex() {
        if (slidingForward()) {
            increaseActiveSlideIndex();
        } else if (slidingBack()) {
            deincreaseActiveSlideIndex();
        }
    }

    /* Slider Actions */

    function slide(index) {
        setActiveSlideIndex(index);
        updateDots();
        translateSlider(calculateCompleteDistance());
    }

    function fakeSwipe(fakeShift) {
        updateInteractionParameters();
        setPointDiffX(fakeShift);
        getSlider().classList.add(SLIDER_CHANGING_CLASS_NAME);
        fixSlider();
    }

    function prevItem(event) {
        preventClick(event);
        if (getActiveSlideIndex() !== 0) {
            fakeSwipe(NEXT_SHIFT + 1);
        }
    }

    function nextItem(event) {
        preventClick(event);
        if (getActiveSlideIndex() !== getSliderMax()) {
            fakeSwipe(-NEXT_SHIFT - 1);
        }
    }

    function positionSlider() {
        eventTool.trigger(slider, SLIDER_EVENT, false, 'UIEvents');
        eventTool.bind(slider, transition, finalizeSlide);
        getSlider().classList.add(SLIDER_FIXING_CLASS_NAME);
        translateSlider(calculateCompleteDistance());
    }

    function fixSlider() {
        if (Math.abs(pointDiffX) > SLIDE_THRESHOLD) {
            updateIndex();
            updateDots();
            positionSlider();
        }
    }

    /* Slider Interactions */

    function touchStart(event) {
        if (!getSlider().classList.contains(SLIDER_FIXING_CLASS_NAME) || !getSlider().classList.contains(SLIDER_CHANGING_CLASS_NAME)) {
            updateInteractionParameters(event);
            eventTool.bind(document, 'touchmove', touchMove);
            eventTool.bind(document, 'touchend', touchEnd);
        }
    }

    function touchMove(event) {
        setPointDiffX(event.touches[0].pageX - getPointStartX());
        if (Math.abs(getPointDiffX()) > SLIDE_THRESHOLD) {
            event.preventDefault();
            setAnimationFrame(requestAnimationFrame(shiftSlider));
        }
    }

    function touchEnd() {
        eventTool.unbind(document, 'touchmove', touchMove);
        eventTool.unbind(document, 'touchend', touchEnd);
        cancelAnimationFrame(getAnimationFrame());
        requestAnimationFrame(fixSlider);
    }

    function interactions() {
        eventTool.bind(getSlider(), 'touchstart', touchStart);
    }

    /* Slider Inititalization */

    function setDefaultValues() {
        setSlider();
        setSliderDotClassName();
        setSliderDots();
        setSliderMax();
        setActiveSlideIndex(0);
        setActiveSlideDot();
    }

    function init() {
        setDefaultValues();
        interactions();
    }

    init();

    /* Slider Interface */

    return {
        prev: prevItem,
        next: nextItem,
        set: slide
    };
}

/* Interface */

exports.dots = dots;
exports.init = init;

},{"./tx-createNode":7,"./tx-event":8,"./tx-transition":12,"./tx-translate":13}],12:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {
  var transition;
  var element = document.createElement('element');
  var transitions = {
    'transition': 'transitionend',
    'oTransition': 'oTransitionEnd',
    'MSTransition': 'MSTransitionEnd',
    'MozTransition': 'transitionend',
    'WebkitTransition': 'webkitTransitionEnd'
  };
  for (transition in transitions) {
    if (element.style[transition] !== undefined) {
      return transitions[transition];
    }
  }
};

},{}],13:[function(require,module,exports){

/* jshint browser:true */

'use strict';

/* Utilities */

function properties(axis, distance) {
  var property = 'translate' + axis.toUpperCase() + '(' + distance + ')';
  return {
    property: property,
    propertyLayer: property + ' translateZ(0)'
  };
}

/* CSS Object */

function translateCSS(axis, distance) {
  var css = properties(axis, distance);
  return {
    '-webkit-transform': css.propertyLayer,
    '-moz-transform': css.propertyLayer,
    '-ms-transform': css.property,
    '-o-transform': css.property,
    'transform': css.propertyLayer
  };
}

/* CSS String */

function translateString(axis, distance) {
  var css = properties(axis, distance);
  return '-webkit-transform:' + css.propertyLayer + ';-moz-transform:' + css.propertyLayer + ';-ms-transform:' + css.property + ';-o-transform:' + css.property + ';transform:' + css.propertyLayer + ';';
}

/* Interface */

exports.css = translateCSS;
exports.string = translateString;

},{}],14:[function(require,module,exports){

/* jshint browser:true */
/* global google */

'use strict';

module.exports = function (_) {
    var GM_SCRIPT_URL = 'http://maps.google.com/maps/api/js?sensor=false';
    var MARKER_ICON = '/assets/frontend/images/marker.png';

    var MAP_STYLES = require('ui/mapStyles');

    var MAP_CLASS_NAME = 'contactMap';

    var maps = void 0;
    var centers = void 0;

    function initMarker(center, map, icon) {
        return new google.maps.Marker({
            position: center,
            map: map,
            icon: MARKER_ICON
        });
    }

    function initMap(dom) {
        var latlon = dom.getAttribute('data-location').split(',');
        if (dom) {
            var center = new google.maps.LatLng(latlon[0] - 0, latlon[1] - 0);
            centers.push(center);
            var options = {
                center: center,
                zoom: 16,
                disableDefaultUI: true,
                styles: MAP_STYLES
            };
            var map = new google.maps.Map(dom, options);
            initMarker(center, map);
            return map;
        }
    }

    function centerMap(map, index) {
        map.setCenter(centers[index]);
    }

    function onWindowResize() {
        requestAnimationFrame(function (_) {
            return maps.forEach(centerMap);
        });
    }

    function init() {
        centers = [];
        maps = [].slice.call(document.getElementsByClassName(MAP_CLASS_NAME)).map(initMap);
        window.addEventListener('resize', onWindowResize);
    }

    function loadScript() {
        var script = document.createElement('script');
        script.addEventListener('load', init);
        script.type = 'text/javascript';
        document.body.appendChild(script);
        script.src = GM_SCRIPT_URL;
    }

    if (document.getElementsByClassName(MAP_CLASS_NAME).length > 0) {
        loadScript();
    }
};

},{"ui/mapStyles":21}],15:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (id) {

    var device = require('device')();

    var INDEX_CLASS_LIST = 'page-index';

    var FEEDBACK_ID = 'feedback';
    var FEEDBACK_HOLDER_ID = 'feedbackForm';

    var REVEAL_DURATION = 1500;

    var form = void 0;
    var holder = void 0;
    var targetHeight = void 0;
    var targetScroll = void 0;
    var scrollHeight = void 0;
    var windowHeight = void 0;

    /* Animation */

    function cubicInOut(fraction) {
        return fraction < 0.5 ? 4 * Math.pow(fraction, 3) : (fraction - 1) * (2 * fraction - 2) * (2 * fraction - 2) + 1;
    }

    function runAnimation(startTime, duration, startScroll, deltaValue, task) {
        requestAnimationFrame(function (_) {
            var fraction = (Date.now() - startTime) / duration;
            if (fraction < 1) {
                var currentValue = deltaValue * cubicInOut(fraction);
                revealFeedback(currentValue, startScroll);
                runAnimation(startTime, duration, startScroll, deltaValue, task);
            } else {
                revealFeedback(deltaValue, startScroll);
                cleanUp();
            }
        });
    }

    /* Actions */

    function revealFeedback(currentHeight, startScroll) {
        form.style.height = currentHeight + 'px';
        window.scrollTo(0, startScroll + currentHeight);
    }

    function showFeedback() {
        runAnimation(Date.now(), REVEAL_DURATION, window.pageYOffset, targetHeight, revealFeedback);
    }

    function cleanUp() {
        form = null;
        holder = null;
        scrollHeight = null;
        windowHeight = null;
    }

    function measureHeights() {
        targetHeight = holder.clientHeight;
        targetScroll = holder.scrollTop;
        scrollHeight = document.documentElement.scrollHeight;
        windowHeight = window.innerHeight;
    }

    /* Initialization */

    function onScroll(event) {
        requestAnimationFrame(function (_) {
            if (windowHeight + window.pageYOffset >= scrollHeight) {
                showFeedback();
                window.removeEventListener('scroll', onScroll);
                window.removeEventListener('resize', onResize);
            }
        });
    }

    function onResize() {
        requestAnimationFrame(measureHeights);
    }

    function initializeInteractions() {
        window.addEventListener('scroll', onScroll);
        window.addEventListener('resize', onResize);
    }

    form = document.getElementById(FEEDBACK_ID);

    if (form && document.body.classList.contains(INDEX_CLASS_LIST) && device.desktop()) {
        holder = document.getElementById(FEEDBACK_HOLDER_ID);
        measureHeights();
        initializeInteractions();
    } else {
        return false;
    }
};

},{"device":3}],16:[function(require,module,exports){

/* jshint browser:true */

'use strict';

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

module.exports = function (_) {
    var fileInput = require('patterns/tx-fileInput');
    var steppers = require('ui/steppers');
    var phoneInput = require('ui/phoneInput');

    var FORM_ID = 'checkoutForm';
    var FORM_SUBMIT_ID = 'formSubmit';
    var FORM_ELEMENTS = '.formRequired';
    var FORM_SUBMIT_DISABLED_CLASS_NAME = 'formSubmit-is-disabled';
    var ELEMENT_ERROR_CLASS_NAME = 'formItem-has-error';

    var submit = void 0;
    var elements = void 0;

    fileInput.init('.formAttachment', 'Прикрепить файл', 'Удалить');
    steppers();
    phoneInput();

    function validateElement(element) {
        var value = element.value.trim();
        if (!value || value === '') {
            return false;
        } else {
            return true;
        }
    }

    function validateForm() {
        return elements.every(validateElement);
    }

    function lockForm() {
        submit.setAttribute('disabled', 'disabled');
        submit.classList.add(FORM_SUBMIT_DISABLED_CLASS_NAME);
    }

    function unlockForm() {
        submit.removeAttribute('disabled');
        submit.classList.remove(FORM_SUBMIT_DISABLED_CLASS_NAME);
    }

    function onElementFocus(event) {
        event.target.parentElement.classList.remove(ELEMENT_ERROR_CLASS_NAME);
    }

    function onElementInput(event) {
        if (validateForm()) {
            unlockForm();
        } else {
            lockForm();
        }
    }

    function subscribe() {
        form.addEventListener('input', onElementInput, true);
        form.addEventListener('keyup', onElementInput, true);
        form.addEventListener('change', onElementInput, true);
        form.addEventListener('focus', onElementFocus, true);
    }

    var form = document.getElementById(FORM_ID);
    if (form) {
        elements = [].concat(_toConsumableArray(form.querySelectorAll(FORM_ELEMENTS)));
        submit = document.getElementById(FORM_SUBMIT_ID);
        subscribe();
    }
};

},{"patterns/tx-fileInput":9,"ui/phoneInput":23,"ui/steppers":29}],17:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var galleryOverlay = require('ui/galleryOverlay');
    var gallerySwipe = require('ui/gallerySwipe');

    if (document.getElementById('gallery')) {
        galleryOverlay();
        gallerySwipe();
    }
};

},{"ui/galleryOverlay":18,"ui/gallerySwipe":19}],18:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var GALLERY_ID = 'gallery';
    var GALLERY_LINK_CLASS_NAME = 'galleryLink';
    var GALLERY_OVERLAY_ID = 'galleryOverlay';
    var GALLERY_OVERLAY_ACTIVE_CLASS_NAME = 'galleryOverlay-is-active';
    var GALLERY_OVERLAY_LOADING_CLASS_NAME = 'galleryOverlay-is-loading';
    var GALLERY_OVERLAY_IMAGE_ID = 'galleryFullImage';
    var GALLERY_OVERLAY_PREV_ID = 'galleryPrev';
    var GALLERY_OVERLAY_NEXT_ID = 'galleryNext';
    var GALLERY_OVERLAY_CLOSE_ID = 'galleryClose';
    var GALLERY_OVERLAY_NAV_DOT_CLASS_NAME = 'gNLink';
    var GALLERY_OVERLAY_NAV_DOT_ACTIVER_CLASS_NAME = 'gNLink-is-active';

    var activeIndex = void 0;

    function updateNavigation() {
        galleryDots[activeIndex].classList.add(GALLERY_OVERLAY_NAV_DOT_ACTIVER_CLASS_NAME);
    }

    function clearNavigation() {
        galleryDots[activeIndex].classList.remove(GALLERY_OVERLAY_NAV_DOT_ACTIVER_CLASS_NAME);
    }

    function showOverlay() {
        galleryOverlay.classList.add(GALLERY_OVERLAY_ACTIVE_CLASS_NAME);
    }

    function hideOverlay() {
        clearNavigation();
        galleryOverlay.classList.remove(GALLERY_OVERLAY_ACTIVE_CLASS_NAME);
    }

    function showLoadedImage(imageURL) {
        updateNavigation();
        galleryImage.src = imageURL;
        galleryOverlay.classList.remove(GALLERY_OVERLAY_LOADING_CLASS_NAME);
    }

    function loadImage(imageURL) {
        return new Promise(function (resolve, reject) {
            var image = new Image();
            image.addEventListener('load', function (_) {
                return resolve(imageURL);
            });
            image.addEventListener('error', function (_) {
                return reject(imageURL);
            });
            image.src = imageURL;
        });
    }

    function showImage(imageURL) {
        galleryOverlay.classList.add(GALLERY_OVERLAY_LOADING_CLASS_NAME);
        loadImage(imageURL).then(showLoadedImage);
    }

    function showPrevImage() {
        clearNavigation();
        activeIndex = activeIndex === 0 ? galleryLinks.length - 1 : activeIndex - 1;
        var imageURL = galleryLinks[activeIndex];
        showImage(imageURL);
    }

    function showNextImage() {
        clearNavigation();
        activeIndex = activeIndex === galleryLinks.length - 1 ? 0 : activeIndex + 1;
        var imageURL = galleryLinks[activeIndex];
        showImage(imageURL);
    }

    function onGalleryClick(event) {
        var target = event.target;
        if (target.classList.contains(GALLERY_LINK_CLASS_NAME)) {
            event.preventDefault();
            activeIndex = galleryLinks.indexOf(target);
            showOverlay();
            showImage(target.href);
        }
    }

    function onPrevClick(event) {
        event.preventDefault();
        showPrevImage();
    }

    function onNextClick(event) {
        event.preventDefault();
        showNextImage();
    }

    function onCloseClick(event) {
        event.preventDefault();
        hideOverlay();
    }

    function init() {
        gallery.addEventListener('click', onGalleryClick);
        galleryPrev.addEventListener('click', onPrevClick);
        galleryNext.addEventListener('click', onNextClick);
        galleryClose.addEventListener('click', onCloseClick);
    }

    var gallery = document.getElementById(GALLERY_ID);
    var galleryLinks = [].slice.call(gallery.getElementsByClassName(GALLERY_LINK_CLASS_NAME));
    var galleryOverlay = document.getElementById(GALLERY_OVERLAY_ID);
    var galleryImage = document.getElementById(GALLERY_OVERLAY_IMAGE_ID);
    var galleryNext = document.getElementById(GALLERY_OVERLAY_NEXT_ID);
    var galleryPrev = document.getElementById(GALLERY_OVERLAY_PREV_ID);
    var galleryClose = document.getElementById(GALLERY_OVERLAY_CLOSE_ID);
    var galleryDots = [].slice.call(galleryOverlay.getElementsByClassName(GALLERY_OVERLAY_NAV_DOT_CLASS_NAME));

    init();
};

},{}],19:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var slider = require('patterns/tx-slider');

    var GALLERY_ID = 'galleryItems';
    var GALLERY_ITEM_CLASS_NAME = 'galleryItem';
    var GALLERY_DOTS_CLASS_NAME = 'galleryDots';
    var GALLERY_DOT_CLASS_NAME = 'galleryDot';

    var dots = void 0;

    function init() {
        dots = slider.dots(gallerySize, GALLERY_DOTS_CLASS_NAME, GALLERY_DOT_CLASS_NAME);
        gallery.parentElement.appendChild(dots);
        slider.init(gallery, dots, GALLERY_DOT_CLASS_NAME);
    }

    var gallery = document.getElementById(GALLERY_ID);
    var galleryItems = [].slice.call(gallery.getElementsByClassName(GALLERY_ITEM_CLASS_NAME));
    var gallerySize = galleryItems.length;

    init();
};

},{"patterns/tx-slider":11}],20:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var TAB_CLASS_NAME = 'tabLink';
    var TAB_ACTIVE_CLASS_NAME = 'tabLink-is-active';
    var TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME = 'tabContent-is-active';

    var activeTab = void 0;
    var activeContent = void 0;

    function deactivateActive() {
        activeTab.classList.remove(TAB_ACTIVE_CLASS_NAME);
        activeContent.classList.remove(TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME);
    }

    function activateNew(tab, content) {
        tab.classList.add(TAB_ACTIVE_CLASS_NAME);
        content.classList.add(TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME);
    }

    function onClick(event, link, content) {
        event.preventDefault();
        if (link !== activeTab) {
            if (activeTab) {
                deactivateActive();
            }
            activateNew(link, content);
            activeTab = link;
            activeContent = content;
        } else {
            deactivateActive();
            activeTab = null;
            activeContent = null;
        }
    }

    function addPair(link, index) {
        var contentId = link.getAttribute('href').replace('#', '');
        var content = document.getElementById(contentId);
        link.addEventListener('click', function (event) {
            return onClick(event, link, content);
        });
        if (index === 0) {
            activeTab = link;
            activeContent = content;
        }
    }

    var tabObjects = document.getElementsByClassName(TAB_CLASS_NAME);

    if (tabObjects) {
        tabObjects = [].slice.call(tabObjects);
        tabObjects.forEach(addPair);
    }
};

},{}],21:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = [{
    'elementType': 'geometry',
    'featureType': 'water',
    'stylers': [{
        'color': '#e9e9e9'
    }, {
        'lightness': 17
    }]
}, {
    'elementType': 'geometry',
    'featureType': 'landscape',
    'stylers': [{
        'color': '#f5f5f5'
    }, {
        'lightness': 20
    }]
}, {
    'elementType': 'geometry.fill',
    'featureType': 'road.highway',
    'stylers': [{
        'color': '#ffffff'
    }, {
        'lightness': 17
    }]
}, {
    'elementType': 'geometry.stroke',
    'featureType': 'road.highway',
    'stylers': [{
        'color': '#ffffff'
    }, {
        'lightness': 29
    }, {
        'weight': 0.2
    }]
}, {
    'elementType': 'geometry',
    'featureType': 'road.arterial',
    'stylers': [{
        'color': '#ffffff'
    }, {
        'lightness': 18
    }]
}, {
    'elementType': 'geometry',
    'featureType': 'road.local',
    'stylers': [{
        'color': '#ffffff'
    }, {
        'lightness': 16
    }]
}, {
    'elementType': 'geometry',
    'featureType': 'poi',
    'stylers': [{
        'color': '#f5f5f5'
    }, {
        'lightness': 21
    }]
}, {
    'elementType': 'geometry',
    'featureType': 'poi.park',
    'stylers': [{
        'color': '#dedede'
    }, {
        'lightness': 21
    }]
}, {
    'elementType': 'labels.text.stroke',
    'stylers': [{
        'visibility': 'on'
    }, {
        'color': '#ffffff'
    }, {
        'lightness': 16
    }]
}, {
    'elementType': 'labels.text.fill',
    'stylers': [{
        'saturation': 36
    }, {
        'color': '#333333'
    }, {
        'lightness': 40
    }]
}, {
    'elementType': 'labels.icon',
    'stylers': [{
        'visibility': 'off'
    }]
}, {
    'elementType': 'geometry',
    'featureType': 'transit',
    'stylers': [{
        'color': '#f2f2f2'
    }, {
        'lightness': 19
    }]
}, {
    'elementType': 'geometry.fill',
    'featureType': 'administrative',
    'stylers': [{
        'color': '#fefefe'
    }, {
        'lightness': 20
    }]
}, {
    'elementType': 'geometry.stroke',
    'featureType': 'administrative',
    'stylers': [{
        'color': '#fefefe'
    }, {
        'lightness': 17
    }, {
        'weight': 1.2
    }]
}];

},{}],22:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var NAV_ID = 'navigation';
    var NAV_TOGGLE_ID = 'navToggle';
    var NAV_ITEM_CLASS_NAME = 'navItem';
    var NAV_ITEM_ACTIVE_CLASS_NAME = 'navItem-is-active';
    var FEEDBACK_ID = 'feedback';
    var FEEDBACK_SHOW_NAV_ID = 'showFeedback';
    var FEEDBACK_SHOW_SIDE_ID = 'writeUs';
    var FEEDBACK_SHOW_ASK_ID = 'askQuestion';
    var FEEDBACK_CLOSE_ID = 'closeFeedback';
    var CART_ID = 'cart';
    var CART_ACTIVE_CLASS_NAME = 'cart-is-active';
    var ACTIVE_SUFFIX = '-is-active';
    var BACK_LINK_ID = 'backLink';

    var navigation = void 0;
    var navigationActive = void 0;
    var navigationItems = void 0;
    var navToggle = void 0;
    var navToggleActive = void 0;
    var feedback = void 0;
    var feedbackShowNav = void 0;
    var feedbackShowSide = void 0;
    var feedbackShowAsk = void 0;
    var feedbackClose = void 0;
    var feedbackActive = void 0;
    var cartHolder = void 0;
    var backLink = void 0;

    function toggleNav() {
        navToggle.classList.toggle(navToggleActive);
        navigation.classList.toggle(navigationActive);
    }

    function clearItemData() {
        feedback.removeAttribute('data-item-id');
    }

    function insertItemData(id) {
        feedback.setAttribute('data-item-id', id);
    }

    function toggleFeedback() {
        feedback.reset();
        feedback.classList.toggle(feedbackActive);
    }

    function onNavClick(event) {
        event.preventDefault();
        event.stopPropagation();
        toggleNav();
    }

    function onFeedbackClick(event) {
        event.preventDefault();
        event.stopPropagation();
        toggleFeedback();
        clearItemData();
    }

    function onFeedbackItemClick(event) {
        onFeedbackClick(event);
        insertItemData(feedbackShowAsk.getAttribute('data-item-id'));
    }

    function onCartOver(event) {
        event.target.classList.add(CART_ACTIVE_CLASS_NAME);
    }

    function onCartOut(event) {
        event.target.classList.remove(CART_ACTIVE_CLASS_NAME);
    }

    function initInteractions() {
        navToggle.addEventListener('click', onNavClick);
        feedbackShowNav.addEventListener('click', onFeedbackClick);
        feedbackClose.addEventListener('click', onFeedbackClick);
        if (feedbackShowSide) {
            feedbackShowSide.addEventListener('click', onFeedbackClick);
        }
        if (feedbackShowAsk) {
            feedbackShowAsk.addEventListener('click', onFeedbackItemClick);
        }
        cartHolder.addEventListener('mouseenter', onCartOver);
        cartHolder.addEventListener('mouseleave', onCartOut);
    }

    function onBackClick(event) {
        event.preventDefault();
        if (window.history.length > 0) {
            window.history.back();
        }
    }

    function initNavItemIntreactions() {
        [].slice.call(navigationItems).forEach(function (item) {
            item.addEventListener('mouseenter', function () {
                return item.classList.add(NAV_ITEM_ACTIVE_CLASS_NAME);
            });
            item.addEventListener('mouseleave', function () {
                return item.classList.remove(NAV_ITEM_ACTIVE_CLASS_NAME);
            });
        });
    }

    navigation = document.getElementById(NAV_ID);
    if (navigation) {
        navigationActive = '' + NAV_ID + ACTIVE_SUFFIX;
        navigationItems = document.getElementsByClassName(NAV_ITEM_CLASS_NAME);
        navToggle = document.getElementById(NAV_TOGGLE_ID);
        navToggleActive = '' + NAV_TOGGLE_ID + ACTIVE_SUFFIX;
        feedback = document.getElementById(FEEDBACK_ID);
        feedbackShowNav = document.getElementById(FEEDBACK_SHOW_NAV_ID);
        feedbackShowSide = document.getElementById(FEEDBACK_SHOW_SIDE_ID);
        feedbackShowAsk = document.getElementById(FEEDBACK_SHOW_ASK_ID);
        feedbackClose = document.getElementById(FEEDBACK_CLOSE_ID);
        feedbackActive = '' + FEEDBACK_ID + ACTIVE_SUFFIX;
        cartHolder = document.getElementById(CART_ID);
        initInteractions();
        initNavItemIntreactions();
    }

    backLink = document.getElementById(BACK_LINK_ID);
    if (backLink) {
        backLink.addEventListener('click', onBackClick);
    }
};

},{}],23:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var Numbered = require('input.numbered');

    var PHONE_INPUT_CLASS_NAME = 'formField-phone';
    var ERROR_CLASS_NAME = 'formItem-has-error';

    var OPTIONS = {
        mask: '+7 (###) ### - ## - ##',
        numbered: '#',
        empty: '_',
        placeholder: true
    };

    var phoneFields = void 0;

    function onBlur(event) {
        var target = event.target;
        var filtered = phoneFields.filter(function (phoneField) {
            return phoneField.dom === target;
        });
        var valid = filtered[0].numbered.validate();
        if (valid <= 0) {
            target.parentElement.classList.add(ERROR_CLASS_NAME);
        }
    }

    function onFocus(event) {
        event.target.parentElement.classList.remove(ERROR_CLASS_NAME);
    }

    function initField(field) {
        var numbered = new Numbered(field, OPTIONS);
        field.addEventListener('blur', onBlur);
        field.addEventListener('focus', onFocus);
        return {
            dom: field,
            numbered: numbered
        };
    }

    function init() {
        phoneFields = fields.map(initField);
    }

    var fields = [].slice.call(document.getElementsByClassName(PHONE_INPUT_CLASS_NAME));

    init();
};

},{"input.numbered":33}],24:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var TAB_CLASS_NAME = 'shopNavLink-toggle';
    var TAB_ACTIVE_CLASS_NAME = 'shopNavLink-is-active';
    var TAB_CONTENT_HOLDER_CLASS_NAME = 'subNav';

    var activeTab = void 0;
    var activeContent = void 0;

    function deactivateActive() {
        activeTab.classList.remove(TAB_ACTIVE_CLASS_NAME);
        activeContent.removeAttribute('style');
    }

    function activateNew(tab, content) {
        var height = content.getElementsByClassName(TAB_CONTENT_HOLDER_CLASS_NAME)[0].clientHeight;
        tab.classList.add(TAB_ACTIVE_CLASS_NAME);
        content.style.height = height + 'px';
    }

    function onClick(event, link, content) {
        event.preventDefault();
        if (link !== activeTab) {
            if (activeTab) {
                deactivateActive();
            }
            activateNew(link, content);
            activeTab = link;
            activeContent = content;
        } else {
            deactivateActive();
            activeTab = null;
            activeContent = null;
        }
    }

    function addPair(link) {
        var contentId = link.getAttribute('href').replace('#', '');
        var content = document.getElementById(contentId);
        link.addEventListener('click', function (event) {
            return onClick(event, link, content);
        });
    }

    var tabObjects = document.getElementsByClassName(TAB_CLASS_NAME);
    if (tabObjects) {
        tabObjects = [].slice.call(tabObjects);
        tabObjects.forEach(addPair);
    }
};

},{}],25:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var TAB_CLASS_NAME = 'sideShopNavLink-toggle';
    var TAB_ACTIVE_CLASS_NAME = 'sideShopNavLink-is-active';
    var TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME = 'sideSubNavHolder-is-active';
    var BODY_SHIFT_CLASS_NAME = 'page-is-showingSideSubNav';

    var activeTab = void 0;
    var activeContent = void 0;

    function deactivateActive() {
        activeTab.classList.remove(TAB_ACTIVE_CLASS_NAME);
        activeContent.classList.remove(TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME);
        document.body.classList.remove(BODY_SHIFT_CLASS_NAME);
    }

    function activateNew(tab, content) {
        tab.classList.add(TAB_ACTIVE_CLASS_NAME);
        content.classList.add(TAB_CONTENT_HOLDER_ACTIVE_CLASS_NAME);
        document.body.classList.add(BODY_SHIFT_CLASS_NAME);
    }

    function onClick(event, link, content) {
        event.preventDefault();
        if (link !== activeTab) {
            if (activeTab) {
                deactivateActive();
            }
            activateNew(link, content);
            activeTab = link;
            activeContent = content;
        } else {
            deactivateActive();
            activeTab = null;
            activeContent = null;
        }
    }

    function addPair(link) {
        var contentId = link.getAttribute('href').replace('#', '');
        var content = document.getElementById(contentId);
        link.addEventListener('click', function (event) {
            return onClick(event, link, content);
        });
    }

    var tabObjects = document.getElementsByClassName(TAB_CLASS_NAME);

    if (tabObjects) {
        tabObjects = [].slice.call(tabObjects);
        tabObjects.forEach(addPair);
    }
};

},{}],26:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var BATTTERIES_TAB_ID = 'sideSubNavPhoneToggle-batteries';
    var BATTTERIES_TAB_CONTENT_HOLDER_ID = 'sideSubNavPhoneHolder-batteries';
    var BATTTERIES_TAB_CONTENT_ID = 'sideSubNavPhone-batteries';
    var BATTTERIES_TAB_ACTIVE_CLASS_NAME = 'sideNavPhoneLink-battery-is-active';

    var ACCESSORIES_TAB_ID = 'sideSubNavPhoneToggle-accessories';
    var ACCESSORIES_TAB_CONTENT_HOLDER_ID = 'sideSubNavPhoneHolder-accessories';
    var ACCESSORIES_CONTENT_ID = 'sideSubNavPhone-accessories';
    var ACCESSORIES_TAB_ACTIVE_CLASS_NAME = 'sideNavPhoneLink-accessory-is-active';

    var batHolder = void 0;
    var batContent = void 0;

    var accHolder = void 0;
    var accContent = void 0;

    function batDeactivate() {
        batToggle.classList.remove(BATTTERIES_TAB_ACTIVE_CLASS_NAME);
        batHolder.removeAttribute('style');
        batActive = false;
    }

    function accDeactivate() {
        accToggle.classList.remove(ACCESSORIES_TAB_ACTIVE_CLASS_NAME);
        accHolder.removeAttribute('style');
        accActive = false;
    }

    function batActivate() {
        var height = batContent.clientHeight;
        batToggle.classList.add(BATTTERIES_TAB_ACTIVE_CLASS_NAME);
        batHolder.style.height = height + 'px';
        console.log(height);
        batActive = true;
    }

    function accActivate() {
        var height = accContent.clientHeight;
        accToggle.classList.add(ACCESSORIES_TAB_ACTIVE_CLASS_NAME);
        accHolder.style.height = height + 'px';
        accActive = true;
    }

    function onBatClick(event, link, content) {
        event.preventDefault();
        if (batActive) {
            batDeactivate();
        } else {
            batActivate();
            accDeactivate();
        }
    }

    function onAccClick(event, link, content) {
        event.preventDefault();
        if (accActive) {
            accDeactivate();
        } else {
            accActivate();
            batDeactivate();
        }
    }

    var batToggle = document.getElementById(BATTTERIES_TAB_ID);
    var batActive = false;

    if (batToggle) {
        batHolder = document.getElementById(BATTTERIES_TAB_CONTENT_HOLDER_ID);
        batContent = document.getElementById(BATTTERIES_TAB_CONTENT_ID);
        batToggle.addEventListener('click', onBatClick);
    }

    var accToggle = document.getElementById(ACCESSORIES_TAB_ID);
    var accActive = false;

    if (accToggle) {
        accHolder = document.getElementById(ACCESSORIES_TAB_CONTENT_HOLDER_ID);
        accContent = document.getElementById(ACCESSORIES_CONTENT_ID);
        accToggle.addEventListener('click', onAccClick);
    }
};

},{}],27:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var SOCIAL_VK_ID = 'socialLink-FB';
    var SOCIAL_FB_ID = 'socialLink-VK';

    function onSocialClick(event) {
        event.preventDefault();
        var width = 626;
        var height = 305;
        var leftPosition = window.screen.width / 2 - (width / 2 + 10);
        var topPosition = window.screen.height / 2 - (height / 2 + 50);
        var windowFeatures = 'status=no,height=' + height + ',width=' + width + ',resizable=no,left=' + leftPosition + ',top=' + topPosition + ',screenX=' + leftPosition + ',screenY=' + topPosition + ',toolbar=no,menubar=no,scrollbars=no,location=no,directories=no';
        window.open(event.target.href, 'sharer', windowFeatures);
    }

    var socialFB = document.getElementById(SOCIAL_FB_ID);
    var socialVK = document.getElementById(SOCIAL_VK_ID);

    if (socialFB) {
        socialFB.addEventListener('click', onSocialClick);
    }

    if (socialVK) {
        socialVK.addEventListener('click', onSocialClick);
    }
};

},{}],28:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (dom) {

    var eventManager = require('patterns/tx-event');

    var STEP = 1;

    var currentValue = void 0;

    function getCurrentValue() {
        currentValue = field.value - 0;
    }

    function triggerEvent() {
        eventManager.trigger(field, 'ast:change', true, 'UIEvent');
    }

    function updateValue(change) {
        var newValue = currentValue + change;
        currentValue = newValue < 1 ? 1 : newValue;
        field.value = currentValue;
        triggerEvent();
    }

    function onIncreaseClick(event) {
        event.preventDefault();
        updateValue(STEP);
    }

    function onDecreaseClick(event) {
        event.preventDefault();
        updateValue(-STEP);
    }

    function onChange() {
        getCurrentValue();
        triggerEvent();
    }

    var field = dom.getElementsByClassName('aSField')[0];
    var increase = dom.getElementsByClassName('aSIncrease')[0];
    var decrease = dom.getElementsByClassName('aSDecrease')[0];

    increase.addEventListener('click', onIncreaseClick);
    decrease.addEventListener('click', onDecreaseClick);
    field.addEventListener('change', onChange);
    field.addEventListener('input', onChange);
    getCurrentValue();
};

},{"patterns/tx-event":8}],29:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var stepper = require('ui/stepper');

    var STEPPER_CLASS_NAME = 'ammountStepper';

    function initStepper(dom) {
        stepper(dom);
    }

    var steppers = [].slice.call(document.getElementsByClassName(STEPPER_CLASS_NAME)).map(initStepper);
};

},{"ui/stepper":28}],30:[function(require,module,exports){

/* jshint browser:true */

'use strict';

module.exports = function (_) {

    var TILES_ID = 'tiles';
    var TILES_HOVERED_SUFFIX = '-is-hoveredOver';
    var TILE_CLASS_NAME = 'tile';

    var tilesHovered = void 0;

    function checkTile(event) {
        return event.target.classList.contains(TILE_CLASS_NAME);
    }

    function onMouseOver(event) {
        if (checkTile(event)) {
            tiles.classList.add(tilesHovered);
        }
    }

    function onMouseOut(event) {
        if (checkTile(event)) {
            tiles.classList.remove(tilesHovered);
        }
    }

    var tiles = document.getElementById(TILES_ID);
    if (tiles) {
        tilesHovered = '' + TILES_ID + TILES_HOVERED_SUFFIX;
        tiles.addEventListener('mouseover', onMouseOver);
        tiles.addEventListener('mouseout', onMouseOut);
    }
};

},{}],31:[function(require,module,exports){

/* jshint browser:true */

'use strict';

/* Utilities */

var loadFonts = require('patterns/tx-loadFonts');

loadFonts('Open Sans', ['PFDinDisplayPro', 'PFDinDisplayProBlack', 'ACityNovaBold']);

/* UI */

var contacts = require('ui/contacts');
var feedback = require('ui/feedback');
var form = require('ui/form');
var gallery = require('ui/gallery');
var infoTabs = require('ui/infoTabs');
var navigation = require('ui/navigation');
var shopNav = require('ui/shopNavigation');
var sideNav = require('ui/sideNavigation');
var sideNavPhone = require('ui/sideNavigationPhone');
var social = require('ui/social');
var tiles = require('ui/tiles');

contacts();
feedback();
form();
gallery();
infoTabs();
navigation();
shopNav();
sideNav();
sideNavPhone();
tiles();
social();

/* Data */

var feedbackForm = require('data/feedbackForm');

feedbackForm();

/* Catalog */

var filters = require('filter/filters');
var filterTabs = require('filter/filterTabs');

filters();
filterTabs();

/* Cart */

var cart = require('cart/cart');

cart();

},{"cart/cart":1,"data/feedbackForm":2,"filter/filterTabs":5,"filter/filters":6,"patterns/tx-loadFonts":10,"ui/contacts":14,"ui/feedback":15,"ui/form":16,"ui/gallery":17,"ui/infoTabs":20,"ui/navigation":22,"ui/shopNavigation":24,"ui/sideNavigation":25,"ui/sideNavigationPhone":26,"ui/social":27,"ui/tiles":30}],32:[function(require,module,exports){
(function(){'use strict';var f,g=[];function l(a){g.push(a);1==g.length&&f()}function m(){for(;g.length;)g[0](),g.shift()}f=function(){setTimeout(m)};function n(a){this.a=p;this.b=void 0;this.f=[];var b=this;try{a(function(a){q(b,a)},function(a){r(b,a)})}catch(c){r(b,c)}}var p=2;function t(a){return new n(function(b,c){c(a)})}function u(a){return new n(function(b){b(a)})}function q(a,b){if(a.a==p){if(b==a)throw new TypeError;var c=!1;try{var d=b&&b.then;if(null!=b&&"object"==typeof b&&"function"==typeof d){d.call(b,function(b){c||q(a,b);c=!0},function(b){c||r(a,b);c=!0});return}}catch(e){c||r(a,e);return}a.a=0;a.b=b;v(a)}}
function r(a,b){if(a.a==p){if(b==a)throw new TypeError;a.a=1;a.b=b;v(a)}}function v(a){l(function(){if(a.a!=p)for(;a.f.length;){var b=a.f.shift(),c=b[0],d=b[1],e=b[2],b=b[3];try{0==a.a?"function"==typeof c?e(c.call(void 0,a.b)):e(a.b):1==a.a&&("function"==typeof d?e(d.call(void 0,a.b)):b(a.b))}catch(h){b(h)}}})}n.prototype.g=function(a){return this.c(void 0,a)};n.prototype.c=function(a,b){var c=this;return new n(function(d,e){c.f.push([a,b,d,e]);v(c)})};
function w(a){return new n(function(b,c){function d(c){return function(d){h[c]=d;e+=1;e==a.length&&b(h)}}var e=0,h=[];0==a.length&&b(h);for(var k=0;k<a.length;k+=1)u(a[k]).c(d(k),c)})}function x(a){return new n(function(b,c){for(var d=0;d<a.length;d+=1)u(a[d]).c(b,c)})};window.Promise||(window.Promise=n,window.Promise.resolve=u,window.Promise.reject=t,window.Promise.race=x,window.Promise.all=w,window.Promise.prototype.then=n.prototype.c,window.Promise.prototype["catch"]=n.prototype.g);}());

(function(){function l(a,b){document.addEventListener?a.addEventListener("scroll",b,!1):a.attachEvent("scroll",b)}function m(a){document.body?a():document.addEventListener?document.addEventListener("DOMContentLoaded",function c(){document.removeEventListener("DOMContentLoaded",c);a()}):document.attachEvent("onreadystatechange",function k(){if("interactive"==document.readyState||"complete"==document.readyState)document.detachEvent("onreadystatechange",k),a()})};function r(a){this.a=document.createElement("div");this.a.setAttribute("aria-hidden","true");this.a.appendChild(document.createTextNode(a));this.b=document.createElement("span");this.c=document.createElement("span");this.h=document.createElement("span");this.f=document.createElement("span");this.g=-1;this.b.style.cssText="max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;";this.c.style.cssText="max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;";
this.f.style.cssText="max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;";this.h.style.cssText="display:inline-block;width:200%;height:200%;font-size:16px;max-width:none;";this.b.appendChild(this.h);this.c.appendChild(this.f);this.a.appendChild(this.b);this.a.appendChild(this.c)}
function t(a,b){a.a.style.cssText="max-width:none;min-width:20px;min-height:20px;display:inline-block;overflow:hidden;position:absolute;width:auto;margin:0;padding:0;top:-999px;left:-999px;white-space:nowrap;font-synthesis:none;font:"+b+";"}function y(a){var b=a.a.offsetWidth,c=b+100;a.f.style.width=c+"px";a.c.scrollLeft=c;a.b.scrollLeft=a.b.scrollWidth+100;return a.g!==b?(a.g=b,!0):!1}function z(a,b){function c(){var a=k;y(a)&&a.a.parentNode&&b(a.g)}var k=a;l(a.b,c);l(a.c,c);y(a)};function A(a,b){var c=b||{};this.family=a;this.style=c.style||"normal";this.weight=c.weight||"normal";this.stretch=c.stretch||"normal"}var B=null,C=null,E=null,F=null;function G(){if(null===C)if(J()&&/Apple/.test(window.navigator.vendor)){var a=/AppleWebKit\/([0-9]+)(?:\.([0-9]+))(?:\.([0-9]+))/.exec(window.navigator.userAgent);C=!!a&&603>parseInt(a[1],10)}else C=!1;return C}function J(){null===F&&(F=!!document.fonts);return F}
function K(){if(null===E){var a=document.createElement("div");try{a.style.font="condensed 100px sans-serif"}catch(b){}E=""!==a.style.font}return E}function L(a,b){return[a.style,a.weight,K()?a.stretch:"","100px",b].join(" ")}
A.prototype.load=function(a,b){var c=this,k=a||"BESbswy",q=0,D=b||3E3,H=(new Date).getTime();return new Promise(function(a,b){if(J()&&!G()){var M=new Promise(function(a,b){function e(){(new Date).getTime()-H>=D?b():document.fonts.load(L(c,'"'+c.family+'"'),k).then(function(c){1<=c.length?a():setTimeout(e,25)},function(){b()})}e()}),N=new Promise(function(a,c){q=setTimeout(c,D)});Promise.race([N,M]).then(function(){clearTimeout(q);a(c)},function(){b(c)})}else m(function(){function u(){var b;if(b=-1!=
f&&-1!=g||-1!=f&&-1!=h||-1!=g&&-1!=h)(b=f!=g&&f!=h&&g!=h)||(null===B&&(b=/AppleWebKit\/([0-9]+)(?:\.([0-9]+))/.exec(window.navigator.userAgent),B=!!b&&(536>parseInt(b[1],10)||536===parseInt(b[1],10)&&11>=parseInt(b[2],10))),b=B&&(f==v&&g==v&&h==v||f==w&&g==w&&h==w||f==x&&g==x&&h==x)),b=!b;b&&(d.parentNode&&d.parentNode.removeChild(d),clearTimeout(q),a(c))}function I(){if((new Date).getTime()-H>=D)d.parentNode&&d.parentNode.removeChild(d),b(c);else{var a=document.hidden;if(!0===a||void 0===a)f=e.a.offsetWidth,
g=n.a.offsetWidth,h=p.a.offsetWidth,u();q=setTimeout(I,50)}}var e=new r(k),n=new r(k),p=new r(k),f=-1,g=-1,h=-1,v=-1,w=-1,x=-1,d=document.createElement("div");d.dir="ltr";t(e,L(c,"sans-serif"));t(n,L(c,"serif"));t(p,L(c,"monospace"));d.appendChild(e.a);d.appendChild(n.a);d.appendChild(p.a);document.body.appendChild(d);v=e.a.offsetWidth;w=n.a.offsetWidth;x=p.a.offsetWidth;I();z(e,function(a){f=a;u()});t(e,L(c,'"'+c.family+'",sans-serif'));z(n,function(a){g=a;u()});t(n,L(c,'"'+c.family+'",serif'));
z(p,function(a){h=a;u()});t(p,L(c,'"'+c.family+'",monospace'))})})};"undefined"!==typeof module?module.exports=A:(window.FontFaceObserver=A,window.FontFaceObserver.prototype.load=A.prototype.load);}());

},{}],33:[function(require,module,exports){
/*! numbered v1.0.2 | pavel-yagodin | MIT License | https://github.com/CSSSR/jquery.numbered */
(function (root, factory) {
	if (typeof define === 'function' && define.amd) {
		define([], factory);
	} else if (typeof exports === 'object') {
		module.exports = factory();
	} else {
		root.Numbered = factory();
	}
}(this, function () {
	'use strict';

	var defaults = {
		mask: '+7 (###) ### - ## - ##',
		numbered: '#',
		empty: '_',
		placeholder: false
	};

	var Numbered = function (target, params) {
		var self = this;

		if (typeof target !== 'object') {
			self.inputs = document.querySelectorAll(target);
		} else if (typeof target.length !== 'undefined') {
			self.inputs = target;
		} else {
			self.inputs = [target];
		}
		self.inputs = Array.prototype.slice.call(self.inputs);

		params = params || (typeof self.inputs[0].numbered !== 'undefined' ? self.inputs[0].numbered.params : {});

		for (var def in defaults) {
			if (typeof params[def] === 'undefined') {
				params[def] = defaults[def];
			}
		}

		self.params = params;
		self.config = {};

		self.config.placeholder = self.params.mask.replace(new RegExp(self.params.numbered, 'g'), self.params.empty);
		self.config.numbered    = self.params.numbered.replace(/([()[\]\.^\#$|?+-])/g, '\\\\$1');
		self.config.numberedCol = self.params.mask.split(self.params.numbered).length -1;
		self.config.empty       = self.params.empty.replace(/([()[\]\.^\#$|?+-])/g, '\\$1');
		self.config.mask        = self.params.mask.replace(/([()[\]\.^\#$|?+-])/g, '\\$1').replace(new RegExp(self.config.numbered, 'g'), '(\\d)');
		self.config.maskNums    = self.params.mask.replace(/[^\d]/gi, '').split('');
		self.config.maskNumsCol = self.config.maskNums.length;
		self.config.regexp      = new RegExp('^' + self.config.mask + '$');
		self.config.events      = ['input', 'change', 'click', 'focusin', 'blur'];



		self._eventFire = function(el, etype){
			if (el.fireEvent) {
				el.fireEvent('on' + etype);
			} else {
				var evObj = document.createEvent('Events');
				evObj.initEvent(etype, true, false);
				el.dispatchEvent(evObj);
			}
		};

		self._getSelectionRange = function (oElm) {
			var r = { text: '', start: 0, end: 0, length: 0 };
			if (oElm.setSelectionRange) {
				r.start= oElm.selectionStart;
				r.end = oElm.selectionEnd;
				r.text = (r.start != r.end) ? oElm.value.substring(r.start, r.end): '';
			} else if (document.selection) {
				var oR;
				if (oElm.tagName && oElm.tagName === 'TEXTAREA') {
					var oS = document.selection.createRange().duplicate();
					oR = oElm.createTextRange();
					var sB = oS.getBookmark();
					oR.moveToBookmark(sB);
				} else {
					oR = document.selection.createRange().duplicate();
				}

				r.text = oR.text;
				for (; oR.moveStart('character', -1) !== 0; r.start++);
				r.end = r.text.length + r.start;
			}
			r.length = r.text.length;
			return r;
		};


		self.magic = function (event) {
			var numbered = this.numbered;
			var value = numbered.input.value || ' ';
			var valueFormatted = value.replace(/[^\d]/gi, '').split('').join('');
			var valueFormattedArr = valueFormatted.split('');
			var valueFormattedCol = valueFormattedArr.length;
			var valueFormattedIndex = 0;
			var positionStart = -1;
			var positionEnd = -1;
			var positionOld = self._getSelectionRange(numbered.input);
			var maskNumsIndex = 0;
			var valueFormattedRes = [];
			var maskSplit = numbered.params.mask.split('');

			for (var key in maskSplit) {
				var val = maskSplit[key];
				key = parseInt(key);
				if (maskNumsIndex <= numbered.config.maskNumsCol && val == numbered.config.maskNums[maskNumsIndex] && val == valueFormattedArr[valueFormattedIndex]) {
					valueFormattedRes.push(val);
					maskNumsIndex++;
					valueFormattedIndex++;
				} else if(val == numbered.params.numbered) {
					if (positionStart < 0) {
						positionStart = key;
					}
					if(valueFormattedIndex < valueFormattedCol) {
						valueFormattedRes.push(valueFormattedArr[valueFormattedIndex]);
						valueFormattedIndex++;
						positionEnd = key;
					} else {
						valueFormattedRes.push(numbered.params.empty);
					}
				} else {
					valueFormattedRes.push(val);
				}
			}
			value = valueFormattedRes.join('');


			var position = (positionEnd >= 0 ? positionEnd + 1 : positionStart);
			if (event.type !== 'click') {
				if ((event.type === 'blur' || event.type === 'change') && valueFormattedIndex - maskNumsIndex === 0 && !numbered.params.placeholder) {
					this.value = '';
				} else if (numbered.oldValue !== numbered.input.value || event.type === 'focusin') {
					this.value = value;
				}
			}

			if(event.type !== 'change' && event.type !== 'blur' && (event.type !== 'click' || (numbered.lastEvent === 'focusin' && event.type === 'click'))) {
				if (numbered.input.setSelectionRange) {
					numbered.input.setSelectionRange(position, position);
				} else if (numbered.input.createTextRange) {
					var range = numbered.input.createTextRange();
					range.collapse(true);
					range.moveEnd('character', position);
					range.moveStart('character', position);
					range.select();
				}
			}

			numbered.oldValue = this.value;
			numbered.lastEvent = event.type;
			return event.target;
		};

		for (var index in self.inputs) {
			var $input = self.inputs[index];
			var is = false;
			if (typeof $input.numbered === 'оbject' || typeof $input.numbered !== 'undefined') {
				is = true;
			}
			$input.numbered = {
				input: self.inputs[index],
				config: self.config,
				params: self.params,
				oldValue: false
			};

			if (!is) {
				for (var key in self.config.events) {
					$input.addEventListener(self.config.events[key], self.magic);
				}
				self._eventFire($input, 'blur');
			}
			self.inputs[index] = $input;
		}

		self.destroy = function () {
			var self = this;
			for (var index in self.inputs) {
				var $input = self.inputs[index];

				for (var key in self.config.events) {
					$input.removeEventListener(self.config.events[key], self.magic);
					$input.numbered = null;
				}
			}
			return null;
		};

		self.validate = function () {
			var self = this;
			var res = self.inputs.length > 1 ? [] : false;
			for (var index in self.inputs) {
				var $input = self.inputs[index];
				var validate;

				if (self.inputs[index].numbered.config.regexp.test(self.inputs[index].numbered.input.value)) {
					validate = 1;
				} else if (self.inputs[index].numbered.input.value === '' || self.inputs[index].numbered.input.value === self.inputs[index].numbered.config.placeholder) {
					validate = 0;
				} else {
					validate = -1;
				}

				if (self.inputs.length > 1) {
					res.push(validate);
				} else {
					res = validate;
				}
			}
			return res;
		};

		self.reInit = function () {
			var self = this;
			var res = self.inputs.length > 1 ? [] : false;
			for (var index in self.inputs) {
				var $input = self.inputs[index];
				self._eventFire($input, 'blur');
			}
			return res;
		};

		self.setVal = function (value) {
			var self = this;
			var res = self.inputs.length > 1 ? [] : false;
			for (var index in self.inputs) {
				var $input = self.inputs[index];
				$input.value = value;
				self._eventFire($input, 'blur');
			}
			return res;
		};

		return self;
	};

	return Numbered;
}));

},{}],34:[function(require,module,exports){
(function (global){
// Best place to find information on XHR features is:
// https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest

var reqfields = [
  'responseType', 'withCredentials', 'timeout', 'onprogress'
]

// Simple and small ajax function
// Takes a parameters object and a callback function
// Parameters:
//  - url: string, required
//  - headers: object of `{header_name: header_value, ...}`
//  - body:
//      + string (sets content type to 'application/x-www-form-urlencoded' if not set in headers)
//      + FormData (doesn't set content type so that browser will set as appropriate)
//  - method: 'GET', 'POST', etc. Defaults to 'GET' or 'POST' based on body
//  - cors: If your using cross-origin, you will need this true for IE8-9
//
// The following parameters are passed onto the xhr object.
// IMPORTANT NOTE: The caller is responsible for compatibility checking.
//  - responseType: string, various compatability, see xhr docs for enum options
//  - withCredentials: boolean, IE10+, CORS only
//  - timeout: long, ms timeout, IE8+
//  - onprogress: callback, IE10+
//
// Callback function prototype:
//  - statusCode from request
//  - response
//    + if responseType set and supported by browser, this is an object of some type (see docs)
//    + otherwise if request completed, this is the string text of the response
//    + if request is aborted, this is "Abort"
//    + if request times out, this is "Timeout"
//    + if request errors before completing (probably a CORS issue), this is "Error"
//  - request object
//
// Returns the request object. So you can call .abort() or other methods
//
// DEPRECATIONS:
//  - Passing a string instead of the params object has been removed!
//
exports.ajax = function (params, callback) {
  // Any variable used more than once is var'd here because
  // minification will munge the variables whereas it can't munge
  // the object access.
  var headers = params.headers || {}
    , body = params.body
    , method = params.method || (body ? 'POST' : 'GET')
    , called = false

  var req = getRequest(params.cors)

  function cb(statusCode, responseText) {
    return function () {
      if (!called) {
        callback(req.status === undefined ? statusCode : req.status,
                 req.status === 0 ? "Error" : (req.response || req.responseText || responseText),
                 req)
        called = true
      }
    }
  }

  req.open(method, params.url, true)

  var success = req.onload = cb(200)
  req.onreadystatechange = function () {
    if (req.readyState === 4) success()
  }
  req.onerror = cb(null, 'Error')
  req.ontimeout = cb(null, 'Timeout')
  req.onabort = cb(null, 'Abort')

  if (body) {
    setDefault(headers, 'X-Requested-With', 'XMLHttpRequest')

    if (!global.FormData || !(body instanceof global.FormData)) {
      setDefault(headers, 'Content-Type', 'application/x-www-form-urlencoded')
    }
  }

  for (var i = 0, len = reqfields.length, field; i < len; i++) {
    field = reqfields[i]
    if (params[field] !== undefined)
      req[field] = params[field]
  }

  for (var field in headers)
    req.setRequestHeader(field, headers[field])

  req.send(body)

  return req
}

function getRequest(cors) {
  // XDomainRequest is only way to do CORS in IE 8 and 9
  // But XDomainRequest isn't standards-compatible
  // Notably, it doesn't allow cookies to be sent or set by servers
  // IE 10+ is standards-compatible in its XMLHttpRequest
  // but IE 10 can still have an XDomainRequest object, so we don't want to use it
  if (cors && global.XDomainRequest && !/MSIE 1/.test(navigator.userAgent))
    return new XDomainRequest
  if (global.XMLHttpRequest)
    return new XMLHttpRequest
}

function setDefault(obj, key, value) {
  obj[key] = obj[key] || value
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{}]},{},[31]);
